package Puissance4;


import java.util.Scanner;





public class Puissance4 {
	
	public static void main(String[] args) {// Code de départ
		System.out.println("Bienvenue");
		int codeMode = ChoixMode();
		switch (codeMode){
		  case 1 : PVP(); break;
		  case 2 :  {int codeModePC = ChoixModePC();
		       switch (codeModePC){
			       case 3 : PVC_facile(); break;
			       case 4 : PVC_moyen(); break;
			       case 5 : PVC_difficle();break;
		    }
		  }
		}
	}
		
		
		
	

	
	public static int ChoixMode() {
		int codeMode = 0;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Choix de mode (options : player vs player /player vs computer)" );
		String Mode = scanner.nextLine().toLowerCase();
		while (codeMode == 0) {
			switch (Mode) {
			case "player vs player" : codeMode = 1; break;
			case "player vs computer" : codeMode = 2; break;
			
			default : {
				System.out.println("Veuillez saisir une mode valide.");
				System.out.println();
				scanner = new Scanner(System.in);
				System.out.println("Choisissez le mode de jeu (options : player vs player /player vs computer)");
				Mode = scanner.nextLine().toLowerCase();
				break;
				}
			}
		}
		return codeMode;
	}
	
	public static int ChoixModePC() {
		int codeModePC = 0;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Choix de mode options : facile / moyen / difficile");
		String Mode = scanner.nextLine().toLowerCase();
		while (codeModePC == 0) {
			switch (Mode) {
			case "facile" : codeModePC = 3; break;
			case "moyen" : codeModePC = 4; break;
			case "difficile" : codeModePC = 5; break;
			default : {
				System.out.println("Veuillez saisir une mode valide.");
				System.out.println();
				scanner = new Scanner(System.in);
				System.out.println("Choix de mode options : facile / moyen / difficile");
				Mode = scanner.nextLine().toLowerCase();
				break;
				}
			}
		}
		return codeModePC;
	}
			
			
			
		
	    ////PP
		public static void PVP() {
			Scanner scanner = new Scanner(System.in);
			System.out.println("Nom du 1er joueur");
			String nom1 = scanner.nextLine();
			System.out.println("Nom du 2eme joueur");
			String nom2 = scanner.nextLine();
			System.out.println("Regles du jeu :");
			System.out.println("Apres avoir choisi le joueur qui commence,chaque joueur place un pion dans une colonne de son choix");
			System.out.println("La partie se termine lorsqu'un joueur a reussi a aligner verticalement,horizontalement");
			System.out.println("ou diagonale 4 pions de sa couleur ou bien quand la grille est pleine.");
			System.out.println("Le premier joueur prend la piece Jaune et le deuxieme joueur prend la piece Rouge.");
			System.out.println(" ");
			System.out.println("Tapper start Si vous etes pret !");
			String bouton = scanner.nextLine().toLowerCase();
			if (bouton.equals("start") ) {
			System.out.println("Aller c'est partie ! Bonne chance !");
			        String[][] panneau = {
			                {"\n|-1-|-2-|-3-|-4-|-5-|-6-|-7-|"},
			                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
			                {"\n|---|---|---|---|---|---|---|"},
			                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
			                {"\n|---|---|---|---|---|---|---|"},
			                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
			                {"\n|---|---|---|---|---|---|---|"},
			                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
			                {"\n|---|---|---|---|---|---|---|"},
			                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
			                {"\n|---|---|---|---|---|---|---|"},
			                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
			                {"\n|---|---|---|---|---|---|---|\n"}
			        };	
			      
		int gagnant = 0;//Initialisation des variables de gain/perte
		
	
		/**
		 * Le cycle de jeu de pvp commence
		 */
		for(int i = 1 ; i <= 42 ; i++){  
			
			//affichage du échiquier:
			System.out.println("Tour " + i + ", Etat du echiquier :");
			//affichage du échiquier:for(int loop = 0 ; loop < 7 ; loop++)
			
			 for (int x = 0; x < panneau.length; x++){
		            for (int y = 0; y<panneau[x].length; y++){
		                System.out.print(panneau[x][y]);
		            }   
			}
			 
			 
			
			//Placements du jeton:
			System.out.println("Tour du joueur " + (i%2==1 ? nom1 : nom2) );//"Jaune" = joueur 1  /  "Rouge"  = joueur 2
			System.out.println("Entrez le numero de la colonne entre 1 et 7 SVP___");
			boolean placement = false;
			int colonne =-1;//Initialiser un numéro de colonne inexistant
			while(!placement){ //la condiction de la boucle est true
				colonne = -1;
				String ligne = scanner.nextLine();
				//vérification que la ligne est un entier entre 1 et 7:
				try{
					colonne = Integer.valueOf(ligne);
					
					if(colonne >= 1 && colonne <= 7){
						if(panneau[1][colonne*2-1] != " "){ //Une situation où une colonne est toute remplie
							System.out.println("Colonne pleine, Veuillez saisir à nouveau le nombre de colonnes___");
						} else {
							placement = true;
						}
					} else {
						System.out.println("Nombre incorrect, Veuillez saisir à nouveau le nombre de colonnes___");
					}
					//Déclarations de résolution d'erreurs	
				}catch(Exception e){System.out.println("Nombre incorrect, Veuillez saisir à nouveau le nombre de colonnes___");}
			}
			
			
			//placement du jeton:
			int rang = 11; // le placement de jeton commence par la base de colonne (ligne 11)
			while(panneau[rang][colonne*2-1] != " "){
				rang=rang-2;//Observez s'il y a une pièce à un point, si oui, passez à la ligne précédente de la colonne.
			}
			panneau[rang][colonne*2-1] = (i%2==1 ? "J" : "R");//Placement des pièces
			
			
			
			//Détection de victoire:
			
			//symbole en cours:
			String jeton = (i%2==1 ? "J" : "R");
			int nombre=0;
			int L=rang;
			int C=colonne*2-1;
			int max = 0;
			//-->  diagonale HG-BD
			L=rang; C=colonne*2-1;nombre=-1;
			while(L >= 0 && C >= 0 && panneau[L][C] == jeton){ L-=2; C-=2; nombre++;}
			L=rang; C=colonne*2-1;
			while(L<=11 && C<=13 && panneau[L][C] == jeton){ L+=2; C+=2; nombre++;}
			if(nombre > max) max= nombre;
			
			
			//-->  diagonale HD-BG
			L=rang; C=colonne*2-1;nombre=-1;
			while(L >= 0 && C <= 13 && panneau[L][C] == jeton){ L-=2; C+=2; nombre++;}
			L=rang; C=colonne*2-1;
			while(L <= 11 && C >=0 && panneau[L][C] == jeton){ L+=2; C-=2; nombre++;}
			if(nombre > max) max= nombre;
			
		
			//-->  verticale:
			L=rang; C=colonne*2-1; nombre=-1;
			while(L >= 0 && panneau[L][C] == jeton){ L-=2; nombre++;}
			L=rang;  
			while(L <= 11 && panneau[L][C] == jeton){ L+=2; nombre++;}
			if(nombre > max) max= nombre;
		
			
			//-->  horizontale:
			L=rang; C=colonne*2-1;nombre=-1;
			while(C >= 0 && panneau[L][C] == jeton){ C-=2; nombre++;}
			 C=colonne*2-1;
			while(C <= 13 && panneau[L][C] == jeton){ C+=2; nombre++;}
			if(nombre > max) max= nombre;
			
			
			
			if(max >= 4){
				gagnant = (i%2==1 ? 1 : 2);
				i = 999;
			}
			
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		}
		
		
		//affichage des résultats:
		// si gagnant == 0 c'est que tout le échiquier s'est remplis sans gagnant, il y a donc égalité
		
		System.out.println();
		System.out.println("#########################");
		System.out.println("    Fin de la partie     ");
		System.out.println("#########################");
		if(gagnant == 0)
			System.out.println("*******EGALITE*******");
		if(gagnant == 1) {
			System.out.println("****"+"Le gagnant est "+nom1+"****");
		    System.out.println(     "Felicitations a "+nom1+" !"  );
		}
		if(gagnant == 2) {
			System.out.println("****"+"Le gagnant est "+nom2+"****");
			System.out.println(     "Felicitations a "+nom2+" !"  );
		}
	    System.out.println(" ");
		System.out.println("____________  Affichage final du panneau______________");
	
		
		for (int x = 0; x < panneau.length; x++){
            for (int y = 0; y<panneau[x].length; y++){
                System.out.print(panneau[x][y]);
            }
        
	}
		System.out.println(" ");
		System.out.println("_________________________FIN____________________________");

		}
			
  }
		
		
	
		
				
				public static void PVC_facile()  {
					Scanner scanner = new Scanner(System.in);
					System.out.println("votre nom :");
					String nom = scanner.nextLine();
					System.out.println("qui commence : " + nom +" ou computer ?");
					String ordre = scanner.nextLine();
				    if(ordre.equals(nom)) {
				    	String[][] panneau = {
				                {"\n|-1-|-2-|-3-|-4-|-5-|-6-|-7-|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|\n"}
				        };	
				    	int gagnant = 0;//Initialisation des variables de gain/perte
						
				    	
						/**
						 * Le cycle de jeu de pp commence
						 */
						for(int i = 1 ; i <= 21 ; i++){  
							
							//affichage du échiquier:
							System.out.println("Tour " + i + ", Etat du echiquier :");
							//affichage du échiquier:for(int loop = 0 ; loop < 7 ; loop++)
							
							 for (int x = 0; x < panneau.length; x++){
						            for (int y = 0; y<panneau[x].length; y++){
						                System.out.print(panneau[x][y]);
						            }
						        
							}
							 System.out.println("Tour du joueur " );//"Jaune" = player  /  "Rouge"  = computeur
								System.out.println("Entrez le numero de la colonne entre 1 et 7 SVP___");
								boolean placement = false;
								int colonne =-1;//Initialiser un numéro de colonne inexistant
								while(!placement){ //la condiction de la boucle est true
									colonne = -1;
									String ligne = scanner.nextLine();
									//vérification que la ligne est un entier entre 1 et 7:
									try{
										colonne = Integer.valueOf(ligne);
										
										if(colonne >= 1 && colonne <= 7){
											if(panneau[1][colonne*2-1] != " "){ //Une situation où une colonne est toute remplie
												System.out.println("Colonne pleine, Veuillez saisir à nouveau le nombre de colonnes___");
											} else {
												placement = true;
											}
										} else {
											System.out.println("Nombre incorrect, Veuillez saisir à nouveau le nombre de colonnes___");
										}
										//Déclarations de résolution d'erreurs	
									}catch(Exception e){System.out.println("Nombre incorrect, Veuillez saisir à nouveau le nombre de colonnes___");}
							}
								
								//placement du jeton:
								int rang = 11;int rangPc=11;
								while(panneau[rang][colonne*2-1] != " "){
									rang=rang-2;//Observez s'il y a une pièce à un point, si oui, passez à la ligne précédente de la colonne.
								}
								panneau[rang][colonne*2-1] = "J";//Placement des pièces
								
								String jeton= ("J");
								int nombre=0;
								int L=rang;
								int C=colonne*2-1;
								int max = 0;
								//-->  diagonale HG-BD
								L=rang; C=colonne*2-1;nombre=-1;
								while(L >= 0 && C >= 0 && panneau[L][C] == jeton){ L-=2; C-=2; nombre++;}
								L=rang; C=colonne*2-1;
								while(L<=11 && C<=13 && panneau[L][C] == jeton){ L+=2; C+=2; nombre++;}
								if(nombre > max) max= nombre;
								
								
								//-->  diagonale HD-BG
								L=rang; C=colonne*2-1;nombre=-1;
								while(L >= 0 && C <= 13 && panneau[L][C] == jeton){ L-=2; C+=2; nombre++;}
								L=rang; C=colonne*2-1;
								while(L <= 11 && C >=0 && panneau[L][C] == jeton){ L+=2; C-=2; nombre++;}
								if(nombre > max) max= nombre;
								
							
								//-->  verticale:
								L=rang; C=colonne*2-1; nombre=-1;
								while(L >= 0 && panneau[L][C] == jeton){ L-=2; nombre++;}
								L=rang;  
								while(L <= 11 && panneau[L][C] == jeton){ L+=2; nombre++;}
								if(nombre > max) max= nombre;
							
								
								//-->  horizontale:
								L=rang; C=colonne*2-1;nombre=-1;
								while(C >= 0 && panneau[L][C] == jeton){ C-=2; nombre++;}
								 C=colonne*2-1;
								while(C <= 13 && panneau[L][C] == jeton){ C+=2; nombre++;}
								if(nombre > max) max= nombre;
								
								if(max >= 4){
									gagnant = 1;
									i = 999; break;
								}
								
								/**
								 * 
								 * verifier pc
								 * 
								 
								 */
								 L=11;
							     C=(int)(Math.random()*13+1);
							      if(C%2 !=1) {
							    	  C++;
							      }
								verifier_a: 
								    for(L=11;L>=1;L-=2) {  
									  if(panneau[L][C] == " ") {
										  panneau[L][C]="R";break verifier_a ;
									  }
								    }
								     if(panneau[1][C]!=" ") {
								    	 verifier_c :
												for(C=1;C<=13;C+=2) {
													
													 for(L=11;L>=1;L-=2) {
														 
														  if(panneau[L][C] == " ") {
															  panneau[L][C]="R";break verifier_c;
														  }
															  
														  
													  }
														
													
												}
								     }
									
							
							
					int nombrePc=-1;
					int maxPc =0;
					int a=L;
					int b=C;
					String jetonPc= ("R");
					a=L; b=C;nombrePc=-1;
					while(a >= 0 && b >= 0 && panneau[a][b] == jetonPc){ a-=2; b-=2; nombrePc++;}
					a=L; b=C;
					while(a<=11 && b<=13 && panneau[a][b] == jetonPc){ a+=2; b+=2; nombrePc++;}
					if(nombrePc > maxPc) maxPc= nombrePc;
					
					
					//-->  diagonale HD-BG
					a=L; b=C;nombrePc=-1;
					while(a >= 0 && b <= 13 && panneau[a][b] == jetonPc){ a-=2; b+=2; nombrePc++;}
					a=L; b=C;
					while(a <= 11 && b >=0 && panneau[a][b] == jetonPc){ a+=2; b-=2; nombrePc++;}
					if(nombrePc > maxPc) maxPc= nombrePc;
					
				
					//-->  verticale:
					a=L; b=C;nombrePc=-1;
					while(a >= 0 && panneau[a][b] == jetonPc){ a-=2; nombrePc++;}
					a=L;  
					while(a <= 11 && panneau[a][b] == jetonPc){ a+=2; nombrePc++;}
					if(nombrePc > maxPc) maxPc= nombrePc;
				
					
					//-->  horizontale:
					a=L; b=C;nombrePc=-1;
					while(b >= 0 && panneau[a][b] == jetonPc){ b-=2; nombrePc++;}
					b=C;
					while(b <= 13 && panneau[a][b] == jetonPc){ b+=2; nombrePc++;}
					if(nombrePc > maxPc) maxPc= nombrePc;
					
					
					
								if(maxPc >= 4){
									gagnant = 2;
									i = 999; break;
								}
								System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
								
						}
								//affichage des résultats:
								// si gagnant == 0 c'est que tout le échiquier s'est remplis sans gagnant, il y a donc égalité
								
								System.out.println();
								System.out.println("#########################");
								System.out.println("    Fin de la partie     ");
								System.out.println("#########################");
								if(gagnant == 0)
									System.out.println("*******EGALITE*******");
								if(gagnant == 1) {
									System.out.println("****"+"Le gagnant est "+nom+"****");
								    System.out.println(     "Felicitations a "+nom+" !"  );
								}
								if(gagnant == 2) {
									System.out.println("****"+"Le gagnant est computer****");
									System.out.println(     "Felicitations a computer!"  );
								}
							    System.out.println(" ");
								System.out.println("____________  Affichage final du panneau______________");
							
								
								for (int x = 0; x < panneau.length; x++){
						            for (int y = 0; y<panneau[x].length; y++){
						                System.out.print(panneau[x][y]);
						            }
						        
							}
								System.out.println(" ");
								System.out.println("_________________________FIN____________________________");
							
				    
				    }else if (ordre.equals("computer")) {
				   
						    	String[][] panneau = {
						                {"\n|-1-|-2-|-3-|-4-|-5-|-6-|-7-|"},
						                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
						                {"\n|---|---|---|---|---|---|---|"},
						                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
						                {"\n|---|---|---|---|---|---|---|"},
						                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
						                {"\n|---|---|---|---|---|---|---|"},
						                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
						                {"\n|---|---|---|---|---|---|---|"},
						                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
						                {"\n|---|---|---|---|---|---|---|"},
						                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
						                {"\n|---|---|---|---|---|---|---|\n"}
						        };
						    	
						      int c=(int)(Math.random()*13+1);
						         if(c%2 !=1) {
						            c++;panneau[11][c]="J";
						        }else {
						        	panneau[11][c]="J";
						        }
						         
						         int gagnant = 0;//Initialisation des variables de gain/perte
									
							    	
									/**
									 * Le cycle de jeu de pp commence
									 */
									for(int i = 1 ; i <= 21 ; i++){  
										
										//affichage du échiquier:
										System.out.println("Tour " + i + ", Etat du echiquier :");
										//affichage du échiquier:for(int loop = 0 ; loop < 7 ; loop++)
										 for (int x = 0; x < panneau.length; x++){
									            for (int y = 0; y<panneau[x].length; y++){
									                System.out.print(panneau[x][y]);
									            }
									        
										}
								         
										
										 System.out.println("Tour du joueur " );//"Jaune" = player  /  "Rouge"  = computeur
											System.out.println("Entrez le numero de la colonne entre 1 et 7 SVP___");
											boolean placement = false;
											int colonne =-1;//Initialiser un numéro de colonne inexistant
											while(!placement){ //la condiction de la boucle est true
												colonne = -1;
												String ligne = scanner.nextLine();
												//vérification que la ligne est un entier entre 1 et 7:
												try{
													colonne = Integer.valueOf(ligne);
													
													if(colonne >= 1 && colonne <= 7){
														if(panneau[1][colonne*2-1] != " "){ //Une situation où une colonne est toute remplie
															System.out.println("Colonne pleine, Veuillez saisir à nouveau le nombre de colonnes___");
														} else {
															placement = true;
														}
													} else {
														System.out.println("Nombre incorrect, Veuillez saisir à nouveau le nombre de colonnes___");
													}
													//Déclarations de résolution d'erreurs	
												}catch(Exception e){System.out.println("Nombre incorrect, Veuillez saisir à nouveau le nombre de colonnes___");}
										}
											
											//placement du jeton:
											int rang = 11;
											while(panneau[rang][colonne*2-1] != " "){
												rang=rang-2;//Observez s'il y a une pièce à un point, si oui, passez à la ligne précédente de la colonne.
											}
											panneau[rang][colonne*2-1] = "R";//Placement des pièces
											
											String jeton= ("R");
											int nombre=0;
											int L=rang;
											int C=colonne*2-1;
											int max = 0;
											//-->  diagonale HG-BD
											L=rang; C=colonne*2-1;nombre=-1;
											while(L >= 0 && C >= 0 && panneau[L][C] == jeton){ L-=2; C-=2; nombre++;}
											L=rang; C=colonne*2-1;
											while(L<=11 && C<=13 && panneau[L][C] == jeton){ L+=2; C+=2; nombre++;}
											if(nombre > max) max= nombre;
											
											
											//-->  diagonale HD-BG
											L=rang; C=colonne*2-1;nombre=-1;
											while(L >= 0 && C <= 13 && panneau[L][C] == jeton){ L-=2; C+=2; nombre++;}
											L=rang; C=colonne*2-1;
											while(L <= 11 && C >=0 && panneau[L][C] == jeton){ L+=2; C-=2; nombre++;}
											if(nombre > max) max= nombre;
											
										
											//-->  verticale:
											L=rang; C=colonne*2-1; nombre=-1;
											while(L >= 0 && panneau[L][C] == jeton){ L-=2; nombre++;}
											L=rang;  
											while(L <= 11 && panneau[L][C] == jeton){ L+=2; nombre++;}
											if(nombre > max) max= nombre;
										
											
											//-->  horizontale:
											L=rang; C=colonne*2-1;nombre=-1;
											while(C >= 0 && panneau[L][C] == jeton){ C-=2; nombre++;}
											 C=colonne*2-1;
											while(C <= 13 && panneau[L][C] == jeton){ C+=2; nombre++;}
											if(nombre > max) max= nombre;
											
											if(max >= 4){
												gagnant = 1;
												i = 999; break;
											}
											
											/**
											 * 
											 * verifier pc
											 * 
											 
											 */
											
											 L=11;
										     C=(int)(Math.random()*13+1);
										      if(C%2 !=1) {
										    	  C++;
										      }
											 verifier_a: 
												    for(L=11;L>=1;L-=2) {  
													  if(panneau[L][C] == " ") {
														  panneau[L][C]="J";break verifier_a ;
													  }
												    }
												     if(panneau[1][C]!=" ") {
												    	 verifier_c :
																for(C=1;C<=13;C+=2) {
																	
																	 for(L=11;L>=1;L-=2) {
																		 
																		  if(panneau[L][C] == " ") {
																			  panneau[L][C]="J";break verifier_c;
																		  }
																			  
																		  
																	  }
																		
																	
																}
												     }
													
											
											
									int nombrePc=-1;
									int maxPc =0;
									int a=L;
									int b=C;
									String jetonPc= ("J");
									a=L; b=C;nombrePc=-1;
									while(a >= 0 && b >= 0 && panneau[a][b] == jetonPc){ a-=2; b-=2; nombrePc++;}
									a=L; b=C;
									while(a<=11 && b<=13 && panneau[a][b] == jetonPc){ a+=2; b+=2; nombrePc++;}
									if(nombrePc > maxPc) maxPc= nombrePc;
									
									
									//-->  diagonale HD-BG
									a=L; b=C;nombrePc=-1;
									while(a >= 0 && b <= 13 && panneau[a][b] == jetonPc){ a-=2; b+=2; nombrePc++;}
									a=L; b=C;
									while(a <= 11 && b >=0 && panneau[a][b] == jetonPc){ a+=2; b-=2; nombrePc++;}
									if(nombrePc > maxPc) maxPc= nombrePc;
									
								
									//-->  verticale:
									a=L; b=C;nombrePc=-1;
									while(a >= 0 && panneau[a][b] == jetonPc){ a-=2; nombrePc++;}
									a=L;  
									while(a <= 11 && panneau[a][b] == jetonPc){ a+=2; nombrePc++;}
									if(nombrePc > maxPc) maxPc= nombrePc;
								
									
									//-->  horizontale:
									a=L; b=C;nombrePc=-1;
									while(b >= 0 && panneau[a][b] == jetonPc){ b-=2; nombrePc++;}
									b=C;
									while(b <= 13 && panneau[a][b] == jetonPc){ b+=2; nombrePc++;}
									if(nombrePc > maxPc) maxPc= nombrePc;
									
									
									
												
											
											if(maxPc >= 4){
												gagnant = 2;
												i = 999; break;
											}
											System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
											
									}
											//affichage des résultats:
											// si gagnant == 0 c'est que tout le échiquier s'est remplis sans gagnant, il y a donc égalité
											
											System.out.println();
											System.out.println("#########################");
											System.out.println("    Fin de la partie     ");
											System.out.println("#########################");
											if(gagnant == 0)
												System.out.println("*******EGALITE*******");
											if(gagnant == 1) {
												System.out.println("****"+"Le gagnant est "+nom+"****");
												System.out.println(     "Felicitations a "+nom+" !"  );

											}
											if(gagnant == 2) {
												System.out.println("****"+"Le gagnant est computer****");
												System.out.println(     "Felicitations a computer!"  );
											}
										    System.out.println(" ");
											System.out.println("____________  Affichage final du panneau______________");
										
											
											for (int x = 0; x < panneau.length; x++){
									            for (int y = 0; y<panneau[x].length; y++){
									                System.out.print(panneau[x][y]);
									            }
									        
										}
											System.out.println(" ");
											System.out.println("_________________________FIN____________________________");
						        
						        
						        
						    
				    }
				    
				    
				    
				    
				    
				}
               
				public static void PVC_moyen()  {
					Scanner scanner = new Scanner(System.in);
					System.out.println("votre nom :");
					String nom = scanner.nextLine();
					System.out.println("qui commence : " + nom +" ou computer ?");
					String ordre = scanner.nextLine();
				    if(ordre.equals(nom)) {
				    	String[][] panneau = {
				                {"\n|-1-|-2-|-3-|-4-|-5-|-6-|-7-|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|\n"}
				        };	
				    	int gagnant = 0;//Initialisation des variables de gain/perte
						
				    	
						/**
						 * Le cycle de jeu de pp commence
						 */
						for(int i = 1 ; i <= 21 ; i++){  
							
							//affichage du échiquier:
							System.out.println("Tour " + i + ", Etat du echiquier :");
							//affichage du échiquier:for(int loop = 0 ; loop < 7 ; loop++)
							
							 for (int x = 0; x < panneau.length; x++){
						            for (int y = 0; y<panneau[x].length; y++){
						                System.out.print(panneau[x][y]);
						            }
						        
							}
							 System.out.println("Tour du "+nom );//"Jaune" = player  /  "Rouge"  = computeur
								System.out.println("Entrez le numero de la colonne entre 1 et 7 SVP___");
								boolean placement = false;
								int colonne =-1;//Initialiser un numéro de colonne inexistant
								while(!placement){ //la condiction de la boucle est true
									colonne = -1;
									String ligne = scanner.nextLine();
									//vérification que la ligne est un entier entre 1 et 7:
									try{
										colonne = Integer.valueOf(ligne);
										
										if(colonne >= 1 && colonne <= 7){
											if(panneau[1][colonne*2-1] != " "){ //Une situation où une colonne est toute remplie
												System.out.println("Colonne pleine, Veuillez saisir à nouveau le nombre de colonnes___");
											} else {
												placement = true;
											}
										} else {
											System.out.println("Nombre incorrect, Veuillez saisir à nouveau le nombre de colonnes___");
										}
										//Déclarations de résolution d'erreurs	
									}catch(Exception e){System.out.println("Nombre incorrect, Veuillez saisir à nouveau le nombre de colonnes___");}
							}
								
								//placement du jeton:
								int rang = 11;
								while(panneau[rang][colonne*2-1] != " "){
									rang=rang-2;//Observez s'il y a une pièce à un point, si oui, passez à la ligne précédente de la colonne.
								}
								panneau[rang][colonne*2-1] = "J";//Placement des pièces
								
								String jeton= ("J");
								int nombre=0;
								int L=rang;
								int C=colonne*2-1;
								int max = 0;
								//-->  diagonale HG-BD
								L=rang; C=colonne*2-1;nombre=-1;
								while(L >= 0 && C >= 0 && panneau[L][C] == jeton){ L-=2; C-=2; nombre++;}
								L=rang; C=colonne*2-1;
								while(L<=11 && C<=13 && panneau[L][C] == jeton){ L+=2; C+=2; nombre++;}
								if(nombre > max) max= nombre;
								
								
								//-->  diagonale HD-BG
								L=rang; C=colonne*2-1;nombre=-1;
								while(L >= 0 && C <= 13 && panneau[L][C] == jeton){ L-=2; C+=2; nombre++;}
								L=rang; C=colonne*2-1;
								while(L <= 11 && C >=0 && panneau[L][C] == jeton){ L+=2; C-=2; nombre++;}
								if(nombre > max) max= nombre;
								
							
								//-->  verticale:
								L=rang; C=colonne*2-1; nombre=-1;
								while(L >= 0 && panneau[L][C] == jeton){ L-=2; nombre++;}
								L=rang;  
								while(L <= 11 && panneau[L][C] == jeton){ L+=2; nombre++;}
								if(nombre > max) max= nombre;
							
								
								//-->  horizontale:
								L=rang; C=colonne*2-1;nombre=-1;
								while(C >= 0 && panneau[L][C] == jeton){ C-=2; nombre++;}
								 C=colonne*2-1;
								while(C <= 13 && panneau[L][C] == jeton){ C+=2; nombre++;}
								if(nombre > max) max= nombre;
								
								if(max >= 4){
									gagnant = 1;
									i = 999; break;
								}
								/**
								 * verifier 4R
								 * 
								 */
								//horizontale
								labe:for(int Ln=11;Ln>=1;Ln-=2) {
										for(int col=1;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln][col+2]=="R"&&panneau[Ln][col+4]=="R"&&panneau[Ln][col+6]=="R"&&Ln==11) {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												if(panneau[Ln][col+2]=="R"&&panneau[Ln][col+4]=="R"&&panneau[Ln][col+6]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
									if(nombre!=999) {
								labe: for(int Ln=11;Ln>=1;Ln-=2) {
										for(int col=3;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln][col-2]=="R"&&panneau[Ln][col+2]=="R"&&panneau[Ln][col+4]=="R"&&Ln==11) {
													panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
												}
												if(panneau[Ln][col-2]=="R"&&panneau[Ln][col+2]=="R"&&panneau[Ln][col+4]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
												}
											}
										}
									 }
									}
									if(nombre!=999) {
								labe:for(int Ln=11;Ln>=1;Ln-=2) {
										for(int col=5;col<=11;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln][col-4]=="R"&&panneau[Ln][col-2]=="R"&&panneau[Ln][col+2]=="R"&&Ln==11) {
													panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
												}
												if(panneau[Ln][col-4]=="R"&&panneau[Ln][col-2]=="R"&&panneau[Ln][col+2]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
												}
											}
										}
									 }
									}
									if(nombre!=999) {
							 labe: for(int Ln=11;Ln>=1;Ln-=2) {
										for(int col=7;col<=13;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln][col-6]=="R"&&panneau[Ln][col-4]=="R"&&panneau[Ln][col-2]=="R"&&Ln==11) {
													panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
												}
												if(panneau[Ln][col-6]=="R"&&panneau[Ln][col-4]=="R"&&panneau[Ln][col-2]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
												}
											}
										}
									 }
									}
									//verticale
									
									if(nombre!=999) {
									 labe:for(int col=1;col<=13;col+=2) {
											for(int Ln=1;Ln<=5;Ln+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+2][col]=="R"&&panneau[Ln+4][col]=="R"&&panneau[Ln+6][col]=="R") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										 }
										}
										
									//BG-HD(VRRR)11-1,1-11
									if(nombre!=999) {
									labe:for(int Ln=11;Ln>=7;Ln-=2) {
											for(int col=1;col<=5;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&Ln==11) {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									//BG-HD(RVRR)11-1,1-11
									if(nombre!=999) {
									labe:for(int Ln=9;Ln>=5;Ln-=2) {
											for(int col=3;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(RRVR)11-1,1-11
									if(nombre!=999) {
									labe:for(int Ln=7;Ln>=3;Ln-=2) {
											for(int col=5;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(RRRV)11-1,1-11
									if(nombre!=999) {
									labe:for(int Ln=5;Ln>=1;Ln-=2) {
											for(int col=7;col<=11;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									
									//BG-HD(VRRR)11-3,1-13
									if(nombre!=999) {
									labe:for(int Ln=11;Ln>=7;Ln-=2) {
											for(int col=3;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&Ln==11) {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									//BG-HD(RVRR)11-3,1-13
									if(nombre!=999) {
									labe:for(int Ln=9;Ln>=5;Ln-=2) {
											for(int col=5;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(RRVR)11-3,1-13
									if(nombre!=999) {
									labe:for(int Ln=7;Ln>=3;Ln-=2) {
											for(int col=7;col<=11;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(RRRV)11-3,1-13
									if(nombre!=999) {
									labe:for(int Ln=5;Ln>=1;Ln-=2) {
											for(int col=9;col<=13;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(VRRR)9-1,1-9
									if(nombre!=999) {
									labe:for(int Ln=9;Ln>=7;Ln-=2) {
											for(int col=1;col<=3;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									//BG-HD(RVRR)9-1,1-9
									if(nombre!=999) {
									labe:for(int Ln=7;Ln>=5;Ln-=2) {
											for(int col=3;col<=5;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(RRVR)9-1,1-9
									if(nombre!=999) {
									labe:for(int Ln=5;Ln>=3;Ln-=2) {
											for(int col=5;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(RRRV)9-1,1-9
									if(nombre!=999) {
									labe:for(int Ln=3;Ln>=1;Ln-=2) {
											for(int col=7;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(VRRR)11-5,3-13
									if(nombre!=999) {
									labe:for(int Ln=11;Ln>=9;Ln-=2) {
											for(int col=5;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&Ln==11) {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									//BG-HD(RVRR)11-5,3-13
									if(nombre!=999) {
									labe:for(int Ln=9;Ln>=7;Ln-=2) {
											for(int col=7;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(RRVR)11-5,3-13
									if(nombre!=999) {
									labe:for(int Ln=7;Ln>=5;Ln-=2) {
											for(int col=9;col<=11;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(RRRV)11-5,3-13
									if(nombre!=999) {
									labe:for(int Ln=5;Ln>=3;Ln-=2) {
											for(int col=11;col<=13;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
								
									//BG-HD(VRRR)11-7,5-13
									if(nombre!=999) {
										int Ln=11;int col=7;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
													
												}
											
										
									}
									//BG-HD(RVRR)11-7,5-13
									if(nombre!=999) {
										int Ln=9;int col=9;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
													
												}
											
										
									}
									//BG-HD(RRVR)11-7,5-13
									if(nombre!=999) {
										int Ln=7;int col=11;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
													
												}
											
										
									}
									//BG-HD(RRRV)11-7,5-13
									if(nombre!=999) {
										int Ln=5;int col=13;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
													
												}
											
										
									}
									//BG-HD(VRRR)7-1,1-7
									if(nombre!=999) {
										int Ln=7;int col=1;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
													
												}
											
										
									}
									//BG-HD(RVRR)7-1,1-7
									if(nombre!=999) {
										int Ln=5;int col=3;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
													
												}
											
										
									}
									//BG-HD(RRVR)7-1,1-7
									if(nombre!=999) {
										int Ln=3;int col=5;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
													
												}
											
										
									}
									//BG-HD(RRRV)7-1,1-7
									if(nombre!=999) {
										int Ln=1;int col=7;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
													
												}
											
										
									}
									
									/**
									 * HG-BD
									 */
									
									// HG-BD(VRRR)1-1,11-11
									if(nombre!=999) {
									labe:for(int Ln=1;Ln<=5;Ln+=2) {
											for(int col=1;col<=5;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(RVRR)1-1,11-11
									if(nombre!=999) {
									labe:for(int Ln=3;Ln<=7;Ln+=2) {
											for(int col=3;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(RRVR)1-1,11-11
									if(nombre!=999) {
									labe:for(int Ln=5;Ln<=9;Ln+=2) {
											for(int col=5;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}					
									// HG-BD(RRRV)1-1,11-11
									if(nombre!=999) {
									labe:for(int Ln=7;Ln<=11;Ln+=2) {
											for(int col=7;col<=11;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&Ln==11) {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(VRRR)3-1,11-9
									if(nombre!=999) {
									labe:for(int Ln=3;Ln<=5;Ln+=2) {
											for(int col=1;col<=3;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(RVRR)3-1,11-9
									if(nombre!=999) {
									labe:for(int Ln=5;Ln<=7;Ln+=2) {
											for(int col=3;col<=5;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(RRVR)3-1,11-9
									if(nombre!=999) {
									labe:for(int Ln=7;Ln<=9;Ln+=2) {
											for(int col=5;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}					
									// HG-BD(RRRV)3-1,11-9
									if(nombre!=999) {
									labe:for(int Ln=11;Ln>=9;Ln-=2) {
											for(int col=7;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln-6][col-6]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&Ln==11) {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													if(panneau[Ln-6][col-6]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(VRRR)1-3,11-13
									if(nombre!=999) {
									labe:for(int Ln=1;Ln<=5;Ln+=2) {
											for(int col=3;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(RVRR)1-3,11-13
									if(nombre!=999) {
									labe:for(int Ln=3;Ln<=7;Ln+=2) {
											for(int col=5;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(RRVR)1-3,11-13
									if(nombre!=999) {
									labe:for(int Ln=5;Ln<=9;Ln+=2) {
											for(int col=7;col<=11;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}					
									// HG-BD(RRRV)1-3,11-13
									if(nombre!=999) {
									labe:for(int Ln=7;Ln<=11;Ln+=2) {
											for(int col=9;col<=13;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&Ln==11) {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(VRRR)1-5,9-13
									if(nombre!=999) {
									labe:for(int Ln=1;Ln<=3;Ln+=2) {
											for(int col=5;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(RVRR)1-5,9-13
									if(nombre!=999) {
									labe:for(int Ln=3;Ln<=5;Ln+=2) {
											for(int col=7;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(RRVR)1-5,9-13
									if(nombre!=999) {
									labe:for(int Ln=5;Ln<=7;Ln+=2) {
											for(int col=9;col<=11;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}					
									// HG-BD(RRRV)1-5,9-13
									if(nombre!=999) {
									labe:for(int Ln=7;Ln<=9;Ln+=2) {
											for(int col=11;col<=13;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(VRRR)1-7,7-13
									if(nombre!=999) {
										int Ln=1;int col=7;
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
												}
											
									}
									// HG-BD(RVRR)1-7,7-13
									if(nombre!=999) {
										int Ln=3;int col=9;
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
												}
											
									}
									// HG-BD(RRVR)1-7,7-13
									if(nombre!=999) {
										int Ln=5;int col=11;
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
												}
											
									}			
									// HG-BD(RRRV)1-7,7-13
									if(nombre!=999) {
										int Ln=7;int col=13;
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
												}
											
									}
									// HG-BD(VRRR)5-1,11-7
									if(nombre!=999) {
										int Ln=5;int col=1;
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
												}
											
									}
									// HG-BD(RVRR)5-1,11-7
									if(nombre!=999) {
										int Ln=7;int col=3;
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
												}
											
									}
									// HG-BD(RRVR)5-1,11-7
									if(nombre!=999) {
										int Ln=9;int col=5;
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
												}
											
									}			
									// HG-BD(RRRV)5-1,11-7
									if(nombre!=999) {
										int Ln=11;int col=7;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&Ln==11) {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
													if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
												}
											
									}
								
								
								
								
								
								
								/**
								 * 
								 *verifier 4J 
								 */
								//horizontale
								if(nombre !=999) {
							  labe:for(int Ln=11;Ln>=1;Ln-=2) {
									for(int col=1;col<=7;col+=2) {
										if (panneau[Ln][col]==" ") {
											if(panneau[Ln][col+2]=="J"&&panneau[Ln][col+4]=="J"&&panneau[Ln][col+6]=="J"&&Ln==11) {
												panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
											}
											if(panneau[Ln][col+2]=="J"&&panneau[Ln][col+4]=="J"&&panneau[Ln][col+6]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
												panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
											}
										}
									}
								}
								}
								if(nombre!=999) {
							labe:for(int Ln=11;Ln>=1;Ln-=2) {
									for(int col=3;col<=9;col+=2) {
										if (panneau[Ln][col]==" ") {
											if(panneau[Ln][col-2]=="J"&&panneau[Ln][col+2]=="J"&&panneau[Ln][col+4]=="J"&&Ln==11) {
												panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
											}
											if(panneau[Ln][col-2]=="J"&&panneau[Ln][col+2]=="J"&&panneau[Ln][col+4]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
												panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
											}
										}
									}
								 }
								}
								if(nombre!=999) {
							labe:for(int Ln=11;Ln>=1;Ln-=2) {
									for(int col=5;col<=11;col+=2) {
										if (panneau[Ln][col]==" ") {
											if(panneau[Ln][col-4]=="J"&&panneau[Ln][col-2]=="J"&&panneau[Ln][col+2]=="J"&&Ln==11) {
												panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
											}
											if(panneau[Ln][col-4]=="J"&&panneau[Ln][col-2]=="J"&&panneau[Ln][col+2]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
												panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
											}
										}
									}
								 }
								}
								if(nombre!=999) {
							labe:for(int Ln=11;Ln>=1;Ln-=2) {
									for(int col=7;col<=13;col+=2) {
										if (panneau[Ln][col]==" ") {
											if(panneau[Ln][col-6]=="J"&&panneau[Ln][col-4]=="J"&&panneau[Ln][col-2]=="J"&&Ln==11) {
												panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
											}
											if(panneau[Ln][col-6]=="J"&&panneau[Ln][col-4]=="J"&&panneau[Ln][col-2]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
												panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
											}
										}
									}
								 }
								}						
								//verticale
								
								if(nombre!=999) {
							  labe:for(int col=1;col<=13;col+=2) {
										for(int Ln=1;Ln<=5;Ln+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+2][col]=="J"&&panneau[Ln+4][col]=="J"&&panneau[Ln+6][col]=="J") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									 }
									}
									
								//BG-HD(VRRR)11-1,1-11
								if(nombre!=999) {
							 labe:for(int Ln=11;Ln>=7;Ln-=2) {
										for(int col=1;col<=5;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&Ln==11) {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								//BG-HD(RVRR)11-1,1-11
								if(nombre!=999) {
								labe:for(int Ln=9;Ln>=5;Ln-=2) {
										for(int col=3;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(RRVR)11-1,1-11
								if(nombre!=999) {
								labe:for(int Ln=7;Ln>=3;Ln-=2) {
										for(int col=5;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(RRRV)11-1,1-11
								if(nombre!=999) {
								labe:for(int Ln=5;Ln>=1;Ln-=2) {
										for(int col=7;col<=11;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+6][col-6]=="J"&&panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								
								//BG-HD(VRRR)11-3,1-13
								if(nombre!=999) {
								labe:for(int Ln=11;Ln>=7;Ln-=2) {
										for(int col=3;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&Ln==11) {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								//BG-HD(RVRR)11-3,1-13
								if(nombre!=999) {
								labe:for(int Ln=9;Ln>=5;Ln-=2) {
										for(int col=5;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(RRVR)11-3,1-13
								if(nombre!=999) {
								labe:for(int Ln=7;Ln>=3;Ln-=2) {
										for(int col=7;col<=11;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(RRRV)11-3,1-13
								if(nombre!=999) {
								labe:for(int Ln=5;Ln>=1;Ln-=2) {
										for(int col=9;col<=13;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+6][col-6]=="J"&&panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(VRRR)9-1,1-9
								if(nombre!=999) {
								labe:for(int Ln=9;Ln>=7;Ln-=2) {
										for(int col=1;col<=3;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								//BG-HD(RVRR)9-1,1-9
								if(nombre!=999) {
							   labe:for(int Ln=7;Ln>=5;Ln-=2) {
										for(int col=3;col<=5;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(RRVR)9-1,1-9
								if(nombre!=999) {
								labe:for(int Ln=5;Ln>=3;Ln-=2) {
										for(int col=5;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(RRRV)9-1,1-9
								if(nombre!=999) {
								labe:for(int Ln=3;Ln>=1;Ln-=2) {
										for(int col=7;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+6][col-6]=="J"&&panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(VRRR)11-5,3-13
								if(nombre!=999) {
								labe:for(int Ln=11;Ln>=9;Ln-=2) {
										for(int col=5;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&Ln==11) {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								//BG-HD(RVRR)11-5,3-13
								if(nombre!=999) {
								labe:for(int Ln=9;Ln>=7;Ln-=2) {
										for(int col=7;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(RRVR)11-5,3-13
								if(nombre!=999) {
								labe:for(int Ln=7;Ln>=5;Ln-=2) {
										for(int col=9;col<=11;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(RRRV)11-5,3-13
								if(nombre!=999) {
								labe:for(int Ln=5;Ln>=3;Ln-=2) {
										for(int col=11;col<=13;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+6][col-6]=="J"&&panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
							
								//BG-HD(VRRR)11-7,5-13
								if(nombre!=999) {
									int Ln=11;int col=7;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
												
											}
										
									
								}
								//BG-HD(RVRR)11-7,5-13
								if(nombre!=999) {
									int Ln=9;int col=9;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
												
											}
										
									
								}
								//BG-HD(RRVR)11-7,5-13
								if(nombre!=999) {
									int Ln=7;int col=11;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
												
											}
										
									
								}
								//BG-HD(RRRV)11-7,5-13
								if(nombre!=999) {
									int Ln=5;int col=13;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
												
											}
										
									
								}
								//BG-HD(VRRR)7-1,1-7
								if(nombre!=999) {
									int Ln=7;int col=1;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
												
											}
										
									
								}
								//BG-HD(RVRR)7-1,1-7
								if(nombre!=999) {
									int Ln=5;int col=3;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
												
											}
										
									
								}
								//BG-HD(RRVR)7-1,1-7
								if(nombre!=999) {
									int Ln=3;int col=5;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
												
											}
										
									
								}
								//BG-HD(RRRV)7-1,1-7
								if(nombre!=999) {
									int Ln=1;int col=7;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
												
											}
										
									
								}
								
								/**
								 * HG-BD
								 */
								
								// HG-BD(VRRR)1-1,11-11
								if(nombre!=999) {
								labe:for(int Ln=1;Ln<=5;Ln+=2) {
										for(int col=1;col<=5;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(RVRR)1-1,11-11
								if(nombre!=999) {
								labe:for(int Ln=3;Ln<=7;Ln+=2) {
										for(int col=3;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(RRVR)1-1,11-11
								if(nombre!=999) {
								labe:for(int Ln=5;Ln<=9;Ln+=2) {
										for(int col=5;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}					
								// HG-BD(RRRV)1-1,11-11
								if(nombre!=999) {
									labe:for(int Ln=7;Ln<=11;Ln+=2) {
											for(int col=7;col<=11;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&Ln==11) {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
								// HG-BD(VRRR)3-1,11-9
								if(nombre!=999) {
								labe:for(int Ln=3;Ln<=5;Ln+=2) {
										for(int col=1;col<=3;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(RVRR)3-1,11-9
								if(nombre!=999) {
								labe:for(int Ln=5;Ln<=7;Ln+=2) {
										for(int col=3;col<=5;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(RRVR)3-1,11-9
								if(nombre!=999) {
								labe:for(int Ln=7;Ln<=9;Ln+=2) {
										for(int col=5;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}					
								// HG-BD(RRRV)3-1,11-9
								if(nombre!=999) {
								labe:for(int Ln=11;Ln>=9;Ln-=2) {
										for(int col=7;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln-6][col-6]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&Ln==11) {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												if(panneau[Ln-6][col-6]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(VRRR)1-3,11-13
								if(nombre!=999) {
								labe:for(int Ln=1;Ln<=5;Ln+=2) {
										for(int col=3;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(RVRR)1-3,11-13
								if(nombre!=999) {
								labe:for(int Ln=3;Ln<=7;Ln+=2) {
										for(int col=5;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(RRVR)1-3,11-13
								if(nombre!=999) {
								labe:for(int Ln=5;Ln<=9;Ln+=2) {
										for(int col=7;col<=11;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}					
								// HG-BD(RRRV)1-3,11-13
								if(nombre!=999) {
								labe:for(int Ln=7;Ln<=11;Ln+=2) {
										for(int col=9;col<=13;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&Ln==11) {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(VRRR)1-5,9-13
								if(nombre!=999) {
								labe:for(int Ln=1;Ln<=3;Ln+=2) {
										for(int col=5;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(RVRR)1-5,9-13
								if(nombre!=999) {
								labe:for(int Ln=3;Ln<=5;Ln+=2) {
										for(int col=7;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(RRVR)1-5,9-13
								if(nombre!=999) {
								labe:for(int Ln=5;Ln<=7;Ln+=2) {
										for(int col=9;col<=11;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}					
								// HG-BD(RRRV)1-5,9-13
								if(nombre!=999) {
								labe:for(int Ln=7;Ln<=9;Ln+=2) {
										for(int col=11;col<=13;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(VRRR)1-7,7-13
								if(nombre!=999) {
									int Ln=1;int col=7;
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
											}
										
								}
								// HG-BD(RVRR)1-7,7-13
								if(nombre!=999) {
									int Ln=3;int col=9;
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
											}
										
								}
								// HG-BD(RRVR)1-7,7-13
								if(nombre!=999) {
									int Ln=5;int col=11;
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
											}
										
								}			
								// HG-BD(RRRV)1-7,7-13
								if(nombre!=999) {
									int Ln=7;int col=13;
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
											}
										
								}
								// HG-BD(VRRR)5-1,11-7
								if(nombre!=999) {
									int Ln=5;int col=1;
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
											}
										
								}
								// HG-BD(RVRR)5-1,11-7
								if(nombre!=999) {
									int Ln=7;int col=3;
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
											}
										
								}
								// HG-BD(RRVR)5-1,11-7
								if(nombre!=999) {
									int Ln=9;int col=5;
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
											}
										
								}			
								// HG-BD(RRRV)5-1,11-7
								if(nombre!=999) {
									int Ln=11;int col=7;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&Ln==11) {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
												if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
											}
										
								}
								if(nombre<4) {							
									 L=11;
								     C=(int)(Math.random()*13+1);
								      if(C%2 !=1) {
								    	  C++;
								      }
								     verifier_a: 
								    for(L=11;L>=1;L-=2) {  
									  if(panneau[L][C] == " ") {
										  panneau[L][C]="R";break verifier_a ;
									  }
								    }
								     if(panneau[1][C]!=" ") {
								    	 verifier_c :
												for(C=1;C<=13;C+=2) {
													
													 for(L=11;L>=1;L-=2) {
														 
														  if(panneau[L][C] == " ") {
															  panneau[L][C]="R";break verifier_c;
														  }
															  
														  
													  }
														
													
												}
								     }
								     
									}
							     
								
							     
								  
								
								
								
								int nombrePc=-1;
								int maxPc =0;
								int a=L;
								int b=C;
								String jetonPc= ("R");
								a=L; b=C;nombrePc=-1;
								while(a >= 0 && b >= 0 && panneau[a][b] == jetonPc){ a-=2; b-=2; nombrePc++;}
								a=L; b=C;
								while(a<=11 && b<=13 && panneau[a][b] == jetonPc){ a+=2; b+=2; nombrePc++;}
								if(nombre > maxPc) maxPc= nombrePc;
								
								
								//-->  diagonale HD-BG
								a=L; b=C;nombrePc=-1;
								while(a >= 0 && b <= 13 && panneau[a][b] == jetonPc){ a-=2; b+=2; nombrePc++;}
								a=L; b=C;
								while(a <= 11 && b >=0 && panneau[a][b] == jetonPc){ a+=2; b-=2; nombrePc++;}
								if(nombrePc > maxPc) maxPc= nombrePc;
								
							
								//-->  verticale:
								a=L; b=C;nombrePc=-1;
								while(a >= 0 && panneau[a][b] == jetonPc){ a-=2; nombrePc++;}
								a=L;  
								while(a <= 11 && panneau[a][b] == jetonPc){ a+=2; nombrePc++;}
								if(nombrePc > maxPc) maxPc= nombrePc;
							
								
								//-->  horizontale:
								a=L; b=C;nombrePc=-1;
								while(b >= 0 && panneau[a][b] == jetonPc){ b-=2; nombrePc++;}
								b=C;
								while(b <= 13 && panneau[a][b] == jetonPc){ b+=2; nombrePc++;}
								if(nombrePc > maxPc) maxPc= nombrePc;
								
								
								if(maxPc >= 4){
									gagnant = 2;
									i = 999; break;
								}
								System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
								
						}
								//affichage des résultats:
								// si gagnant == 0 c'est que tout le échiquier s'est remplis sans gagnant, il y a donc égalité
								
								System.out.println();
								System.out.println("#########################");
								System.out.println("    Fin de la partie     ");
								System.out.println("#########################");
								if(gagnant == 0)
									System.out.println("*******EGALITE*******");
								if(gagnant == 1) {
									System.out.println("****"+"Le gagnant est "+nom+"****");
								    System.out.println(     "Felicitations a "+nom+" !"  );
								}
								if(gagnant == 2) {
									System.out.println("****"+"Le gagnant est computer****");
									System.out.println(     "Felicitations a computer!"  );
								}
							    System.out.println(" ");
								System.out.println("____________  Affichage final du panneau______________");
							
								
								for (int x = 0; x < panneau.length; x++){
						            for (int y = 0; y<panneau[x].length; y++){
						                System.out.print(panneau[x][y]);
						            }
						        
							}
								System.out.println(" ");
								System.out.println("_________________________FIN____________________________");
							
				    /**
				     *computer vs player 
				     * 
				     */
				    }else if(ordre.equals("computer")) {
				    	String[][] panneau = {
				                {"\n|-1-|-2-|-3-|-4-|-5-|-6-|-7-|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|\n"}
				        };	
				    	
				    	
					      int c=(int)(Math.random()*13+1);
					         if(c%2 !=1) {
					            c++;panneau[11][c]="J";
					        }else {
					        	panneau[11][c]="J";
					        }
					         
					         int gagnant = 0;//Initialisation des variables de gain/perte
								
						    	
				    							
				    	
						/**
						 * Le cycle de jeu de pp commence
						 */
						for(int i = 1 ; i <= 21 ; i++){  
							
							//affichage du échiquier:
							System.out.println("Tour " + i + ", Etat du echiquier :");
							//affichage du échiquier:for(int loop = 0 ; loop < 7 ; loop++)
							
							 for (int x = 0; x < panneau.length; x++){
						            for (int y = 0; y<panneau[x].length; y++){
						                System.out.print(panneau[x][y]);
						            }
						        
							}
							 System.out.println("Tour du "+nom );//"Jaune" = player  /  "Rouge"  = computeur
								System.out.println("Entrez le numero de la colonne entre 1 et 7 SVP___");
								boolean placement = false;
								int colonne =-1;//Initialiser un numéro de colonne inexistant
								while(!placement){ //la condiction de la boucle est true
									colonne = -1;
									String ligne = scanner.nextLine();
									//vérification que la ligne est un entier entre 1 et 7:
									try{
										colonne = Integer.valueOf(ligne);
										
										if(colonne >= 1 && colonne <= 7){
											if(panneau[1][colonne*2-1] != " "){ //Une situation où une colonne est toute remplie
												System.out.println("Colonne pleine, Veuillez saisir à nouveau le nombre de colonnes___");
											} else {
												placement = true;
											}
										} else {
											System.out.println("Nombre incorrect, Veuillez saisir à nouveau le nombre de colonnes___");
										}
										//Déclarations de résolution d'erreurs	
									}catch(Exception e){System.out.println("Nombre incorrect, Veuillez saisir à nouveau le nombre de colonnes___");}
							}
								
								//placement du jeton:
								int rang = 11;
								while(panneau[rang][colonne*2-1] != " "){
									rang=rang-2;//Observez s'il y a une pièce à un point, si oui, passez à la ligne précédente de la colonne.
								}
								panneau[rang][colonne*2-1] = "R";//Placement des pièces
								
								String jeton= ("R");
								int nombre=0;
								int L=rang;
								int C=colonne*2-1;
								int max = 0;
								//-->  diagonale HG-BD
								L=rang; C=colonne*2-1;nombre=-1;
								while(L >= 0 && C >= 0 && panneau[L][C] == jeton){ L-=2; C-=2; nombre++;}
								L=rang; C=colonne*2-1;
								while(L<=11 && C<=13 && panneau[L][C] == jeton){ L+=2; C+=2; nombre++;}
								if(nombre > max) max= nombre;
								
								
								//-->  diagonale HD-BG
								L=rang; C=colonne*2-1;nombre=-1;
								while(L >= 0 && C <= 13 && panneau[L][C] == jeton){ L-=2; C+=2; nombre++;}
								L=rang; C=colonne*2-1;
								while(L <= 11 && C >=0 && panneau[L][C] == jeton){ L+=2; C-=2; nombre++;}
								if(nombre > max) max= nombre;
								
							
								//-->  verticale:
								L=rang; C=colonne*2-1; nombre=-1;
								while(L >= 0 && panneau[L][C] == jeton){ L-=2; nombre++;}
								L=rang;  
								while(L <= 11 && panneau[L][C] == jeton){ L+=2; nombre++;}
								if(nombre > max) max= nombre;
							
								
								//-->  horizontale:
								L=rang; C=colonne*2-1;nombre=-1;
								while(C >= 0 && panneau[L][C] == jeton){ C-=2; nombre++;}
								 C=colonne*2-1;
								while(C <= 13 && panneau[L][C] == jeton){ C+=2; nombre++;}
								if(nombre > max) max= nombre;
								
								if(max >= 4){
									gagnant = 1;
									i = 999; break;
								}
								
								/***
								 * 
								 * verifier 4J
								 */
								
								//horizontale
								
								 labe:for(int Ln=11;Ln>=1;Ln-=2) {
										for(int col=1;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln][col+2]=="J"&&panneau[Ln][col+4]=="J"&&panneau[Ln][col+6]=="J"&&Ln==11) {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
												if(panneau[Ln][col+2]=="J"&&panneau[Ln][col+4]=="J"&&panneau[Ln][col+6]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								
									if(nombre!=999) {
								labe:for(int Ln=11;Ln>=1;Ln-=2) {
										for(int col=3;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln][col-2]=="J"&&panneau[Ln][col+2]=="J"&&panneau[Ln][col+4]=="J"&&Ln==11) {
													panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
												}
												if(panneau[Ln][col-2]=="J"&&panneau[Ln][col+2]=="J"&&panneau[Ln][col+4]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
												}
											}
										}
									 }
									}
									if(nombre!=999) {
								labe:for(int Ln=11;Ln>=1;Ln-=2) {
										for(int col=5;col<=11;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln][col-4]=="J"&&panneau[Ln][col-2]=="J"&&panneau[Ln][col+2]=="J"&&Ln==11) {
													panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
												}
												if(panneau[Ln][col-4]=="J"&&panneau[Ln][col-2]=="J"&&panneau[Ln][col+2]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
												}
											}
										}
									 }
									}
									if(nombre!=999) {
								labe:for(int Ln=11;Ln>=1;Ln-=2) {
										for(int col=7;col<=13;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln][col-6]=="J"&&panneau[Ln][col-4]=="J"&&panneau[Ln][col-2]=="J"&&Ln==11) {
													panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
												}
												if(panneau[Ln][col-6]=="J"&&panneau[Ln][col-4]=="J"&&panneau[Ln][col-2]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
												}
											}
										}
									 }
									}						
									//verticale
									
									if(nombre!=999) {
								  labe:for(int col=1;col<=13;col+=2) {
											for(int Ln=1;Ln<=5;Ln+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+2][col]=="J"&&panneau[Ln+4][col]=="J"&&panneau[Ln+6][col]=="J") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										 }
										}
										
									//BG-HD(VRRR)11-1,1-11
									if(nombre!=999) {
								 labe:for(int Ln=11;Ln>=7;Ln-=2) {
											for(int col=1;col<=5;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&Ln==11) {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
													if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									//BG-HD(RVRR)11-1,1-11
									if(nombre!=999) {
									labe:for(int Ln=9;Ln>=5;Ln-=2) {
											for(int col=3;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(RRVR)11-1,1-11
									if(nombre!=999) {
									labe:for(int Ln=7;Ln>=3;Ln-=2) {
											for(int col=5;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(RRRV)11-1,1-11
									if(nombre!=999) {
									labe:for(int Ln=5;Ln>=1;Ln-=2) {
											for(int col=7;col<=11;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+6][col-6]=="J"&&panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									
									//BG-HD(VRRR)11-3,1-13
									if(nombre!=999) {
									labe:for(int Ln=11;Ln>=7;Ln-=2) {
											for(int col=3;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&Ln==11) {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
													if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									//BG-HD(RVRR)11-3,1-13
									if(nombre!=999) {
									labe:for(int Ln=9;Ln>=5;Ln-=2) {
											for(int col=5;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(RRVR)11-3,1-13
									if(nombre!=999) {
									labe:for(int Ln=7;Ln>=3;Ln-=2) {
											for(int col=7;col<=11;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(RRRV)11-3,1-13
									if(nombre!=999) {
									labe:for(int Ln=5;Ln>=1;Ln-=2) {
											for(int col=9;col<=13;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+6][col-6]=="J"&&panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(VRRR)9-1,1-9
									if(nombre!=999) {
									labe:for(int Ln=9;Ln>=7;Ln-=2) {
											for(int col=1;col<=3;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									//BG-HD(RVRR)9-1,1-9
									if(nombre!=999) {
								   labe:for(int Ln=7;Ln>=5;Ln-=2) {
											for(int col=3;col<=5;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(RRVR)9-1,1-9
									if(nombre!=999) {
									labe:for(int Ln=5;Ln>=3;Ln-=2) {
											for(int col=5;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(RRRV)9-1,1-9
									if(nombre!=999) {
									labe:for(int Ln=3;Ln>=1;Ln-=2) {
											for(int col=7;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+6][col-6]=="J"&&panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(VRRR)11-5,3-13
									if(nombre!=999) {
									labe:for(int Ln=11;Ln>=9;Ln-=2) {
											for(int col=5;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&Ln==11) {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
													if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									//BG-HD(RVRR)11-5,3-13
									if(nombre!=999) {
									labe:for(int Ln=9;Ln>=7;Ln-=2) {
											for(int col=7;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(RRVR)11-5,3-13
									if(nombre!=999) {
									labe:for(int Ln=7;Ln>=5;Ln-=2) {
											for(int col=9;col<=11;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(RRRV)11-5,3-13
									if(nombre!=999) {
									labe:for(int Ln=5;Ln>=3;Ln-=2) {
											for(int col=11;col<=13;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+6][col-6]=="J"&&panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
														 panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe; 
													}
													
												}
											}
										}
									}
								
									//BG-HD(VRRR)11-7,5-13
									if(nombre!=999) {
										int Ln=11;int col=7;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
													}
													
												}
											
										
									}
									//BG-HD(RVRR)11-7,5-13
									if(nombre!=999) {
										int Ln=9;int col=9;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
													}
													
												}
											
										
									}
									//BG-HD(RRVR)11-7,5-13
									if(nombre!=999) {
										int Ln=7;int col=11;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
													}
													
												}
											
										
									}
									//BG-HD(RRRV)11-7,5-13
									if(nombre!=999) {
										int Ln=5;int col=13;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
													}
													
												}
											
										
									}
									//BG-HD(VRRR)7-1,1-7
									if(nombre!=999) {
										int Ln=7;int col=1;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
													}
													
												}
											
										
									}
									//BG-HD(RVRR)7-1,1-7
									if(nombre!=999) {
										int Ln=5;int col=3;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
													}
													
												}
											
										
									}
									//BG-HD(RRVR)7-1,1-7
									if(nombre!=999) {
										int Ln=3;int col=5;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
													}
													
												}
											
										
									}
									//BG-HD(RRRV)7-1,1-7
									if(nombre!=999) {
										int Ln=1;int col=7;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
													}
													
												}
											
										
									}
									
									/**
									 * HG-BD
									 */
									
									// HG-BD(VRRR)1-1,11-11
									if(nombre!=999) {
									labe:for(int Ln=1;Ln<=5;Ln+=2) {
											for(int col=1;col<=5;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(RVRR)1-1,11-11
									if(nombre!=999) {
									labe:for(int Ln=3;Ln<=7;Ln+=2) {
											for(int col=3;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(RRVR)1-1,11-11
									if(nombre!=999) {
									labe:for(int Ln=5;Ln<=9;Ln+=2) {
											for(int col=5;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}					
									// HG-BD(RRRV)1-1,11-11
									if(nombre!=999) {
										labe:for(int Ln=7;Ln<=11;Ln+=2) {
												for(int col=7;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&Ln==11) {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
									// HG-BD(VRRR)3-1,11-9
									if(nombre!=999) {
									labe:for(int Ln=3;Ln<=5;Ln+=2) {
											for(int col=1;col<=3;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(RVRR)3-1,11-9
									if(nombre!=999) {
									labe:for(int Ln=5;Ln<=7;Ln+=2) {
											for(int col=3;col<=5;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(RRVR)3-1,11-9
									if(nombre!=999) {
									labe:for(int Ln=7;Ln<=9;Ln+=2) {
											for(int col=5;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}					
									// HG-BD(RRRV)3-1,11-9
									if(nombre!=999) {
									labe:for(int Ln=11;Ln>=9;Ln-=2) {
											for(int col=7;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln-6][col-6]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&Ln==11) {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
													if(panneau[Ln-6][col-6]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(VRRR)1-3,11-13
									if(nombre!=999) {
									labe:for(int Ln=1;Ln<=5;Ln+=2) {
											for(int col=3;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(RVRR)1-3,11-13
									if(nombre!=999) {
									labe:for(int Ln=3;Ln<=7;Ln+=2) {
											for(int col=5;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(RRVR)1-3,11-13
									if(nombre!=999) {
									labe:for(int Ln=5;Ln<=9;Ln+=2) {
											for(int col=7;col<=11;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}					
									// HG-BD(RRRV)1-3,11-13
									if(nombre!=999) {
									labe:for(int Ln=7;Ln<=11;Ln+=2) {
											for(int col=9;col<=13;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&Ln==11) {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(VRRR)1-5,9-13
									if(nombre!=999) {
									labe:for(int Ln=1;Ln<=3;Ln+=2) {
											for(int col=5;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(RVRR)1-5,9-13
									if(nombre!=999) {
									labe:for(int Ln=3;Ln<=5;Ln+=2) {
											for(int col=7;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(RRVR)1-5,9-13
									if(nombre!=999) {
									labe:for(int Ln=5;Ln<=7;Ln+=2) {
											for(int col=9;col<=11;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}					
									// HG-BD(RRRV)1-5,9-13
									if(nombre!=999) {
									labe:for(int Ln=7;Ln<=9;Ln+=2) {
											for(int col=11;col<=13;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(VRRR)1-7,7-13
									if(nombre!=999) {
										int Ln=1;int col=7;
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
													}
												}
											
									}
									// HG-BD(RVRR)1-7,7-13
									if(nombre!=999) {
										int Ln=3;int col=9;
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
													}
												}
											
									}
									// HG-BD(RRVR)1-7,7-13
									if(nombre!=999) {
										int Ln=5;int col=11;
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
													}
												}
											
									}			
									// HG-BD(RRRV)1-7,7-13
									if(nombre!=999) {
										int Ln=7;int col=13;
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
													}
												}
											
									}
									// HG-BD(VRRR)5-1,11-7
									if(nombre!=999) {
										int Ln=5;int col=1;
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
													}
												}
											
									}
									// HG-BD(RVRR)5-1,11-7
									if(nombre!=999) {
										int Ln=7;int col=3;
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
													}
												}
											
									}
									// HG-BD(RRVR)5-1,11-7
									if(nombre!=999) {
										int Ln=9;int col=5;
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
													}
												}
											
									}			
									// HG-BD(RRRV)5-1,11-7
									if(nombre!=999) {
										int Ln=11;int col=7;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&Ln==11) {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
													}
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
													}
												}
											
									}
								
								/**
								 * 
								 * verifier JOUER
								 * 
								 
								 */
								//horizontale
								if(nombre!=999) {
									
							labe:for(int Ln=11;Ln>=1;Ln-=2) {
									for(int col=1;col<=7;col+=2) {
										if (panneau[Ln][col]==" ") {
											if(panneau[Ln][col+2]=="R"&&panneau[Ln][col+4]=="R"&&panneau[Ln][col+6]=="R"&&Ln==11) {
												panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
											}
											if(panneau[Ln][col+2]=="R"&&panneau[Ln][col+4]=="R"&&panneau[Ln][col+6]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
												panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
											}
										}
									}
								}
								}
								if(nombre!=999) {
							labe: for(int Ln=11;Ln>=1;Ln-=2) {
									for(int col=3;col<=9;col+=2) {
										if (panneau[Ln][col]==" ") {
											if(panneau[Ln][col-2]=="R"&&panneau[Ln][col+2]=="R"&&panneau[Ln][col+4]=="R"&&Ln==11) {
												panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
											}
											if(panneau[Ln][col-2]=="R"&&panneau[Ln][col+2]=="R"&&panneau[Ln][col+4]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
												panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
											}
										}
									}
								 }
								}
								if(nombre!=999) {
							labe: for(int Ln=11;Ln>=1;Ln-=2) {
									for(int col=5;col<=11;col+=2) {
										if (panneau[Ln][col]==" ") {
											if(panneau[Ln][col-4]=="R"&&panneau[Ln][col-2]=="R"&&panneau[Ln][col+2]=="R"&&Ln==11) {
												panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
											}
											if(panneau[Ln][col-4]=="R"&&panneau[Ln][col-2]=="R"&&panneau[Ln][col+2]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
												panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
											}
										}
									}
								 }
								}
								if(nombre!=999) {
							labe:for(int Ln=11;Ln>=1;Ln-=2) {
									for(int col=7;col<=13;col+=2) {
										if (panneau[Ln][col]==" ") {
											if(panneau[Ln][col-6]=="R"&&panneau[Ln][col-4]=="R"&&panneau[Ln][col-2]=="R"&&Ln==11) {
												panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
											}
											if(panneau[Ln][col-6]=="R"&&panneau[Ln][col-4]=="R"&&panneau[Ln][col-2]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
												panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
											}
										}
									}
								 }
								}
								//verticale
								
								if(nombre!=999) {
								 labe:for(int col=1;col<=13;col+=2) {
										for(int Ln=1;Ln<=5;Ln+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+2][col]=="R"&&panneau[Ln+4][col]=="R"&&panneau[Ln+6][col]=="R") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									 }
									}
									
								//BG-HD(VRRR)11-1,1-11
								if(nombre!=999) {
								labe:for(int Ln=11;Ln>=7;Ln-=2) {
										for(int col=1;col<=5;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&Ln==11) {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
												if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								//BG-HD(RVRR)11-1,1-11
								if(nombre!=999) {
								labe:for(int Ln=9;Ln>=5;Ln-=2) {
										for(int col=3;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(RRVR)11-1,1-11
								if(nombre!=999) {
								labe:for(int Ln=7;Ln>=3;Ln-=2) {
										for(int col=5;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(RRRV)11-1,1-11
								if(nombre!=999) {
								labe:for(int Ln=5;Ln>=1;Ln-=2) {
										for(int col=7;col<=11;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								
								//BG-HD(VRRR)11-3,1-13
								if(nombre!=999) {
								labe:for(int Ln=11;Ln>=7;Ln-=2) {
										for(int col=3;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&Ln==11) {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
												if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								//BG-HD(RVRR)11-3,1-13
								if(nombre!=999) {
								labe:for(int Ln=9;Ln>=5;Ln-=2) {
										for(int col=5;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(RRVR)11-3,1-13
								if(nombre!=999) {
								labe:for(int Ln=7;Ln>=3;Ln-=2) {
										for(int col=9;col<=11;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(RRRV)11-3,1-13
								if(nombre!=999) {
								labe:for(int Ln=5;Ln>=1;Ln-=2) {
										for(int col=9;col<=13;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(VRRR)9-1,1-9
								if(nombre!=999) {
								labe:for(int Ln=9;Ln>=7;Ln-=2) {
										for(int col=1;col<=3;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								//BG-HD(RVRR)9-1,1-9
								if(nombre!=999) {
								labe:for(int Ln=7;Ln>=5;Ln-=2) {
										for(int col=3;col<=5;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(RRVR)9-1,1-9
								if(nombre!=999) {
								labe:for(int Ln=5;Ln>=3;Ln-=2) {
										for(int col=5;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(RRRV)9-1,1-9
								if(nombre!=999) {
								labe:for(int Ln=3;Ln>=1;Ln-=2) {
										for(int col=7;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(VRRR)11-5,3-13
								if(nombre!=999) {
								labe:for(int Ln=11;Ln>=9;Ln-=2) {
										for(int col=5;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&Ln==11) {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
												if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								//BG-HD(RVRR)11-5,3-13
								if(nombre!=999) {
								labe:for(int Ln=9;Ln>=7;Ln-=2) {
										for(int col=7;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(RRVR)11-5,3-13
								if(nombre!=999) {
								labe:for(int Ln=7;Ln>=5;Ln-=2) {
										for(int col=9;col<=11;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(RRRV)11-5,3-13
								if(nombre!=999) {
								labe:for(int Ln=5;Ln>=3;Ln-=2) {
										for(int col=11;col<=13;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
							
								//BG-HD(VRRR)11-7,5-13
								if(nombre!=999) {
									int Ln=11;int col=7;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
												}
												
											}
										
									
								}
								//BG-HD(RVRR)11-7,5-13
								if(nombre!=999) {
									int Ln=9;int col=9;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
												}
												
											}
										
									
								}
								//BG-HD(RRVR)11-7,5-13
								if(nombre!=999) {
									int Ln=7;int col=11;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
												}
												
											}
										
									
								}
								//BG-HD(RRRV)11-7,5-13
								if(nombre!=999) {
									int Ln=5;int col=13;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
												}
												
											}
										
									
								}
								//BG-HD(VRRR)7-1,1-7
								if(nombre!=999) {
									int Ln=7;int col=1;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
												}
												
											}
										
									
								}
								//BG-HD(RVRR)7-1,1-7
								if(nombre!=999) {
									int Ln=5;int col=3;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
												}
												
											}
										
									
								}
								//BG-HD(RRVR)7-1,1-7
								if(nombre!=999) {
									int Ln=3;int col=5;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
												}
												
											}
										
									
								}
								//BG-HD(RRRV)7-1,1-7
								if(nombre!=999) {
									int Ln=1;int col=7;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
												}
												
											}
										
									
								}
								
								/**
								 * HG-BD
								 */
								
								// HG-BD(VRRR)1-1,11-11
								if(nombre!=999) {
								labe:for(int Ln=1;Ln<=5;Ln+=2) {
										for(int col=1;col<=5;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(RVRR)1-1,11-11
								if(nombre!=999) {
								labe:for(int Ln=3;Ln<=7;Ln+=2) {
										for(int col=3;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(RRVR)1-1,11-11
								if(nombre!=999) {
								labe:for(int Ln=5;Ln<=9;Ln+=2) {
										for(int col=5;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}					
								// HG-BD(RRRV)1-1,11-11
								if(nombre!=999) {
									labe:for(int Ln=7;Ln<=11;Ln+=2) {
											for(int col=7;col<=11;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&Ln==11) {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
													if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
								// HG-BD(VRRR)3-1,11-9
								if(nombre!=999) {
								labe:for(int Ln=3;Ln<=5;Ln+=2) {
										for(int col=1;col<=3;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(RVRR)3-1,11-9
								if(nombre!=999) {
								labe:for(int Ln=5;Ln<=7;Ln+=2) {
										for(int col=3;col<=5;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(RRVR)3-1,11-9
								if(nombre!=999) {
								labe:for(int Ln=7;Ln<=9;Ln+=2) {
										for(int col=5;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}					
								// HG-BD(RRRV)3-1,11-9
								if(nombre!=999) {
								labe:for(int Ln=11;Ln>=9;Ln-=2) {
										for(int col=7;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln-6][col-6]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&Ln==11) {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
												if(panneau[Ln-6][col-6]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(VRRR)1-3,11-13
								if(nombre!=999) {
								labe:for(int Ln=1;Ln<=5;Ln+=2) {
										for(int col=3;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(RVRR)1-3,11-13
								if(nombre!=999) {
								labe:for(int Ln=3;Ln<=7;Ln+=2) {
										for(int col=5;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(RRVR)1-3,11-13
								if(nombre!=999) {
								labe:for(int Ln=5;Ln<=9;Ln+=2) {
										for(int col=7;col<=11;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}					
								// HG-BD(RRRV)1-3,11-13
								if(nombre!=999) {
								labe:for(int Ln=7;Ln<=11;Ln+=2) {
										for(int col=9;col<=13;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&Ln==11) {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(VRRR)1-5,9-13
								if(nombre!=999) {
								labe:for(int Ln=1;Ln<=3;Ln+=2) {
										for(int col=5;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(RVRR)1-5,9-13
								if(nombre!=999) {
								labe:for(int Ln=3;Ln<=5;Ln+=2) {
										for(int col=7;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(RRVR)1-5,9-13
								if(nombre!=999) {
								labe:for(int Ln=5;Ln<=7;Ln+=2) {
										for(int col=9;col<=11;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}					
								// HG-BD(RRRV)1-5,9-13
								if(nombre!=999) {
								labe:for(int Ln=7;Ln<=9;Ln+=2) {
										for(int col=11;col<=13;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(VRRR)1-7,7-13
								if(nombre!=999) {
									int Ln=1;int col=7;
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
												}
											}
										
								}
								// HG-BD(RVRR)1-7,7-13
								if(nombre!=999) {
									int Ln=3;int col=9;
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
												}
											}
										
								}
								// HG-BD(RRVR)1-7,7-13
								if(nombre!=999) {
									int Ln=5;int col=11;
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
												}
											}
										
								}			
								// HG-BD(RRRV)1-7,7-13
								if(nombre!=999) {
									int Ln=7;int col=13;
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
												}
											}
										
								}
								// HG-BD(VRRR)5-1,11-7
								if(nombre!=999) {
									int Ln=5;int col=1;
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
												}
											}
										
								}
								// HG-BD(RVRR)5-1,11-7
								if(nombre!=999) {
									int Ln=7;int col=3;
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
												}
											}
										
								}
								// HG-BD(RRVR)5-1,11-7
								if(nombre!=999) {
									int Ln=9;int col=5;
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
												}
											}
										
								}			
								// HG-BD(RRRV)5-1,11-7
								if(nombre!=999) {
									int Ln=11;int col=7;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&Ln==11) {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
												}
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
												}
											}
										
								}

								if(nombre<4) {							
								 L=11;
							     C=(int)(Math.random()*13+1);
							      if(C%2 !=1) {
							    	  C++;
							      }
							     verifier_a: 
							    for(L=11;L>=1;L-=2) {  
								  if(panneau[L][C] == " ") {
									  panneau[L][C]="J";break verifier_a ;
								  }
							    }
							     if(panneau[1][C]!=" ") {
							    	 verifier_c :
											for(C=1;C<=13;C+=2) {
												
												 for(L=11;L>=1;L-=2) {
													 
													  if(panneau[L][C] == " ") {
														  panneau[L][C]="J";break verifier_c;
													  }
														  
													  
												  }
													
												
											}
							     }
							     
								}
							     
								  
								
								
								
								int nombrePc=-1;
								int maxPc =0;
								int a=L;
								int b=C;
								String jetonPc= ("J");
								a=L; b=C;nombrePc=-1;
								while(a >= 0 && b >= 0 && panneau[a][b] == jetonPc){ a-=2; b-=2; nombrePc++;}
								a=L; b=C;
								while(a<=11 && b<=13 && panneau[a][b] == jetonPc){ a+=2; b+=2; nombrePc++;}
								if(nombre > maxPc) maxPc= nombrePc;
								
								
								//-->  diagonale HD-BG
								a=L; b=C;nombrePc=-1;
								while(a >= 0 && b <= 13 && panneau[a][b] == jetonPc){ a-=2; b+=2; nombrePc++;}
								a=L; b=C;
								while(a <= 11 && b >=0 && panneau[a][b] == jetonPc){ a+=2; b-=2; nombrePc++;}
								if(nombrePc > maxPc) maxPc= nombrePc;
								
							
								//-->  verticale:
								a=L; b=C;nombrePc=-1;
								while(a >= 0 && panneau[a][b] == jetonPc){ a-=2; nombrePc++;}
								a=L;  
								while(a <= 11 && panneau[a][b] == jetonPc){ a+=2; nombrePc++;}
								if(nombrePc > maxPc) maxPc= nombrePc;
							
								
								//-->  horizontale:
								a=L; b=C;nombrePc=-1;
								while(b >= 0 && panneau[a][b] == jetonPc){ b-=2; nombrePc++;}
								b=C;
								while(b <= 13 && panneau[a][b] == jetonPc){ b+=2; nombrePc++;}
								if(nombrePc > maxPc) maxPc= nombrePc;
								
								
								if(maxPc >= 4){
									gagnant = 2;
									i = 999; break;
								}
								System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
								
						}
								//affichage des résultats:
								// si gagnant == 0 c'est que tout le échiquier s'est remplis sans gagnant, il y a donc égalité
								
								System.out.println();
								System.out.println("#########################");
								System.out.println("    Fin de la partie     ");
								System.out.println("#########################");
								if(gagnant == 0)
									System.out.println("*******EGALITE*******");
								if(gagnant == 1) {
									System.out.println("****"+"Le gagnant est "+nom+"****");
								    System.out.println(     "Felicitations a "+nom+" !"  );
								}
								if(gagnant == 2) {
									System.out.println("****"+"Le gagnant est computer****");
									System.out.println(     "Felicitations a computer!"  );
								}
							    System.out.println(" ");
								System.out.println("____________  Affichage final du panneau______________");
							
								
								for (int x = 0; x < panneau.length; x++){
						            for (int y = 0; y<panneau[x].length; y++){
						                System.out.print(panneau[x][y]);
						            }
						        
							}
								System.out.println(" ");
								System.out.println("_________________________FIN____________________________");
							
				    	
				    
				     
				    
				    
				}
		
			}
				
				public static void PVC_difficle() {
					Scanner scanner = new Scanner(System.in);
					System.out.println("votre nom :");
					String nom = scanner.nextLine();
					System.out.println("qui commence : " + nom +" ou computer ?");
					String ordre = scanner.nextLine();
				    if(ordre.equals(nom)) {
				    	String[][] panneau = {
				                {"\n|-1-|-2-|-3-|-4-|-5-|-6-|-7-|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|\n"}
				        };	
				    	int gagnant = 0;//Initialisation des variables de gain/perte
						
				    	
						/**
						 * Le cycle de jeu de pp commence
						 */
						for(int i = 1 ; i <= 21 ; i++){  
							
							//affichage du échiquier:
							System.out.println("Tour " + i + ", Etat du echiquier :");
							//affichage du échiquier:for(int loop = 0 ; loop < 7 ; loop++)
							
							 for (int x = 0; x < panneau.length; x++){
						            for (int y = 0; y<panneau[x].length; y++){
						                System.out.print(panneau[x][y]);
						            }
						        
							}
							 System.out.println("Tour du "+nom );//"Jaune" = player  /  "Rouge"  = computeur
								System.out.println("Entrez le numero de la colonne entre 1 et 7 SVP___");
								boolean placement = false;
								int colonne =-1;//Initialiser un numéro de colonne inexistant
								while(!placement){ //la condiction de la boucle est true
									colonne = -1;
									String ligne = scanner.nextLine();
									//vérification que la ligne est un entier entre 1 et 7:
									try{
										colonne = Integer.valueOf(ligne);
										
										if(colonne >= 1 && colonne <= 7){
											if(panneau[1][colonne*2-1] != " "){ //Une situation où une colonne est toute remplie
												System.out.println("Colonne pleine, Veuillez saisir à nouveau le nombre de colonnes___");
											} else {
												placement = true;
											}
										} else {
											System.out.println("Nombre incorrect, Veuillez saisir à nouveau le nombre de colonnes___");
										}
										//Déclarations de résolution d'erreurs	
									}catch(Exception e){System.out.println("Nombre incorrect, Veuillez saisir à nouveau le nombre de colonnes___");}
							}
								
								//placement du jeton:
								int rang = 11;
								while(panneau[rang][colonne*2-1] != " "){
									rang=rang-2;//Observez s'il y a une pièce à un point, si oui, passez à la ligne précédente de la colonne.
								}
								panneau[rang][colonne*2-1] = "J";//Placement des pièces
								
								String jeton= ("J");
								int nombre=0;
								int L=rang;
								int C=colonne*2-1;
								int max = 0;
								//-->  diagonale HG-BD
								L=rang; C=colonne*2-1;nombre=-1;
								while(L >= 0 && C >= 0 && panneau[L][C] == jeton){ L-=2; C-=2; nombre++;}
								L=rang; C=colonne*2-1;
								while(L<=11 && C<=13 && panneau[L][C] == jeton){ L+=2; C+=2; nombre++;}
								if(nombre > max) max= nombre;
								
								
								//-->  diagonale HD-BG
								L=rang; C=colonne*2-1;nombre=-1;
								while(L >= 0 && C <= 13 && panneau[L][C] == jeton){ L-=2; C+=2; nombre++;}
								L=rang; C=colonne*2-1;
								while(L <= 11 && C >=0 && panneau[L][C] == jeton){ L+=2; C-=2; nombre++;}
								if(nombre > max) max= nombre;
								
							
								//-->  verticale:
								L=rang; C=colonne*2-1; nombre=-1;
								while(L >= 0 && panneau[L][C] == jeton){ L-=2; nombre++;}
								L=rang;  
								while(L <= 11 && panneau[L][C] == jeton){ L+=2; nombre++;}
								if(nombre > max) max= nombre;
							
								
								//-->  horizontale:
								L=rang; C=colonne*2-1;nombre=-1;
								while(C >= 0 && panneau[L][C] == jeton){ C-=2; nombre++;}
								 C=colonne*2-1;
								while(C <= 13 && panneau[L][C] == jeton){ C+=2; nombre++;}
								if(nombre > max) max= nombre;
								
								if(max >= 4){
									gagnant = 1;
									i = 999; break;
								}
								/**
								 * 
								 * verifier pc
								 * 
								 
								 */
								//horizontale
							labe:for(int Ln=11;Ln>=1;Ln-=2) {
									for(int col=1;col<=7;col+=2) {
										if (panneau[Ln][col]==" ") {
											if(panneau[Ln][col+2]=="R"&&panneau[Ln][col+4]=="R"&&panneau[Ln][col+6]=="R"&&Ln==11) {
												panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
											}
											if(panneau[Ln][col+2]=="R"&&panneau[Ln][col+4]=="R"&&panneau[Ln][col+6]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
												panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
											}
										}
									}
								}
								if(nombre!=999) {
							labe: for(int Ln=11;Ln>=1;Ln-=2) {
									for(int col=3;col<=9;col+=2) {
										if (panneau[Ln][col]==" ") {
											if(panneau[Ln][col-2]=="R"&&panneau[Ln][col+2]=="R"&&panneau[Ln][col+4]=="R"&&Ln==11) {
												panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
											}
											if(panneau[Ln][col-2]=="R"&&panneau[Ln][col+2]=="R"&&panneau[Ln][col+4]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
												panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
											}
										}
									}
								 }
								}
								if(nombre!=999) {
							labe:for(int Ln=11;Ln>=1;Ln-=2) {
									for(int col=5;col<=11;col+=2) {
										if (panneau[Ln][col]==" ") {
											if(panneau[Ln][col-4]=="R"&&panneau[Ln][col-2]=="R"&&panneau[Ln][col+2]=="R"&&Ln==11) {
												panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
											}
											if(panneau[Ln][col-4]=="R"&&panneau[Ln][col-2]=="R"&&panneau[Ln][col+2]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
												panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
											}
										}
									}
								 }
								}
								if(nombre!=999) {
						 labe: for(int Ln=11;Ln>=1;Ln-=2) {
									for(int col=7;col<=13;col+=2) {
										if (panneau[Ln][col]==" ") {
											if(panneau[Ln][col-6]=="R"&&panneau[Ln][col-4]=="R"&&panneau[Ln][col-2]=="R"&&Ln==11) {
												panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
											}
											if(panneau[Ln][col-6]=="R"&&panneau[Ln][col-4]=="R"&&panneau[Ln][col-2]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
												panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
											}
										}
									}
								 }
								}
								//verticale
								
								if(nombre!=999) {
								 labe:for(int col=1;col<=13;col+=2) {
										for(int Ln=1;Ln<=5;Ln+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+2][col]=="R"&&panneau[Ln+4][col]=="R"&&panneau[Ln+6][col]=="R") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									 }
									}
									
								//BG-HD(VRRR)11-1,1-11
								if(nombre!=999) {
								labe:for(int Ln=11;Ln>=7;Ln-=2) {
										for(int col=1;col<=5;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&Ln==11) {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								//BG-HD(RVRR)11-1,1-11
								if(nombre!=999) {
								labe:for(int Ln=9;Ln>=5;Ln-=2) {
										for(int col=3;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(RRVR)11-1,1-11
								if(nombre!=999) {
								labe:for(int Ln=7;Ln>=3;Ln-=2) {
										for(int col=5;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(RRRV)11-1,1-11
								if(nombre!=999) {
								labe:for(int Ln=5;Ln>=1;Ln-=2) {
										for(int col=7;col<=11;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								
								//BG-HD(VRRR)11-3,1-13
								if(nombre!=999) {
								labe:for(int Ln=11;Ln>=7;Ln-=2) {
										for(int col=3;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&Ln==11) {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								//BG-HD(RVRR)11-3,1-13
								if(nombre!=999) {
								labe:for(int Ln=9;Ln>=5;Ln-=2) {
										for(int col=5;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(RRVR)11-3,1-13
								if(nombre!=999) {
								labe:for(int Ln=7;Ln>=3;Ln-=2) {
										for(int col=7;col<=11;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(RRRV)11-3,1-13
								if(nombre!=999) {
								labe:for(int Ln=5;Ln>=1;Ln-=2) {
										for(int col=9;col<=13;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(VRRR)9-1,1-9
								if(nombre!=999) {
								labe:for(int Ln=9;Ln>=7;Ln-=2) {
										for(int col=1;col<=3;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								//BG-HD(RVRR)9-1,1-9
								if(nombre!=999) {
								labe:for(int Ln=7;Ln>=5;Ln-=2) {
										for(int col=3;col<=5;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(RRVR)9-1,1-9
								if(nombre!=999) {
								labe:for(int Ln=5;Ln>=3;Ln-=2) {
										for(int col=5;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(RRRV)9-1,1-9
								if(nombre!=999) {
								labe:for(int Ln=3;Ln>=1;Ln-=2) {
										for(int col=7;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(VRRR)11-5,3-13
								if(nombre!=999) {
								labe:for(int Ln=11;Ln>=9;Ln-=2) {
										for(int col=5;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&Ln==11) {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								//BG-HD(RVRR)11-5,3-13
								if(nombre!=999) {
								labe:for(int Ln=9;Ln>=7;Ln-=2) {
										for(int col=7;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(RRVR)11-5,3-13
								if(nombre!=999) {
								labe:for(int Ln=7;Ln>=5;Ln-=2) {
										for(int col=9;col<=11;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
								//BG-HD(RRRV)11-5,3-13
								if(nombre!=999) {
								labe:for(int Ln=5;Ln>=3;Ln-=2) {
										for(int col=11;col<=13;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												
											}
										}
									}
								}
							
								//BG-HD(VRRR)11-7,5-13
								if(nombre!=999) {
									int Ln=11;int col=7;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
												
											}
										
									
								}
								//BG-HD(RVRR)11-7,5-13
								if(nombre!=999) {
									int Ln=9;int col=9;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
												
											}
										
									
								}
								//BG-HD(RRVR)11-7,5-13
								if(nombre!=999) {
									int Ln=7;int col=11;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
												
											}
										
									
								}
								//BG-HD(RRRV)11-7,5-13
								if(nombre!=999) {
									int Ln=5;int col=13;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
												
											}
										
									
								}
								//BG-HD(VRRR)7-1,1-7
								if(nombre!=999) {
									int Ln=7;int col=1;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
												
											}
										
									
								}
								//BG-HD(RVRR)7-1,1-7
								if(nombre!=999) {
									int Ln=5;int col=3;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
												
											}
										
									
								}
								//BG-HD(RRVR)7-1,1-7
								if(nombre!=999) {
									int Ln=3;int col=5;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
												
											}
										
									
								}
								//BG-HD(RRRV)7-1,1-7
								if(nombre!=999) {
									int Ln=1;int col=7;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
												
											}
										
									
								}
								
								/**
								 * HG-BD
								 */
								
								// HG-BD(VRRR)1-1,11-11
								if(nombre!=999) {
								labe:for(int Ln=1;Ln<=5;Ln+=2) {
										for(int col=1;col<=5;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(RVRR)1-1,11-11
								if(nombre!=999) {
								labe:for(int Ln=3;Ln<=7;Ln+=2) {
										for(int col=3;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(RRVR)1-1,11-11
								if(nombre!=999) {
								labe:for(int Ln=5;Ln<=9;Ln+=2) {
										for(int col=5;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}					
								// HG-BD(RRRV)1-1,11-11
								if(nombre!=999) {
									labe:for(int Ln=7;Ln<=11;Ln+=2) {
											for(int col=7;col<=11;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&Ln==11) {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
								// HG-BD(VRRR)3-1,11-9
								if(nombre!=999) {
								labe:for(int Ln=3;Ln<=5;Ln+=2) {
										for(int col=1;col<=3;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(RVRR)3-1,11-9
								if(nombre!=999) {
								labe:for(int Ln=5;Ln<=7;Ln+=2) {
										for(int col=3;col<=5;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(RRVR)3-1,11-9
								if(nombre!=999) {
								labe:for(int Ln=7;Ln<=9;Ln+=2) {
										for(int col=5;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}					
								// HG-BD(RRRV)3-1,11-9
								if(nombre!=999) {
								labe:for(int Ln=11;Ln>=9;Ln-=2) {
										for(int col=7;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln-6][col-6]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&Ln==11) {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												if(panneau[Ln-6][col-6]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(VRRR)1-3,11-13
								if(nombre!=999) {
								labe:for(int Ln=1;Ln<=5;Ln+=2) {
										for(int col=3;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(RVRR)1-3,11-13
								if(nombre!=999) {
								labe:for(int Ln=3;Ln<=7;Ln+=2) {
										for(int col=5;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(RRVR)1-3,11-13
								if(nombre!=999) {
								labe:for(int Ln=5;Ln<=9;Ln+=2) {
										for(int col=7;col<=11;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}					
								// HG-BD(RRRV)1-3,11-13
								if(nombre!=999) {
								labe:for(int Ln=7;Ln<=11;Ln+=2) {
										for(int col=9;col<=13;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&Ln==11) {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(VRRR)1-5,9-13
								if(nombre!=999) {
								labe:for(int Ln=1;Ln<=3;Ln+=2) {
										for(int col=5;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(RVRR)1-5,9-13
								if(nombre!=999) {
								labe:for(int Ln=3;Ln<=5;Ln+=2) {
										for(int col=7;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(RRVR)1-5,9-13
								if(nombre!=999) {
								labe:for(int Ln=5;Ln<=7;Ln+=2) {
										for(int col=9;col<=11;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}					
								// HG-BD(RRRV)1-5,9-13
								if(nombre!=999) {
								labe:for(int Ln=7;Ln<=9;Ln+=2) {
										for(int col=11;col<=13;col+=2) {
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
								// HG-BD(VRRR)1-7,7-13
								if(nombre!=999) {
									int Ln=1;int col=7;
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
											}
										
								}
								// HG-BD(RVRR)1-7,7-13
								if(nombre!=999) {
									int Ln=3;int col=9;
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
											}
										
								}
								// HG-BD(RRVR)1-7,7-13
								if(nombre!=999) {
									int Ln=5;int col=11;
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
											}
										
								}			
								// HG-BD(RRRV)1-7,7-13
								if(nombre!=999) {
									int Ln=7;int col=13;
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
											}
										
								}
								// HG-BD(VRRR)5-1,11-7
								if(nombre!=999) {
									int Ln=5;int col=1;
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
											}
										
								}
								// HG-BD(RVRR)5-1,11-7
								if(nombre!=999) {
									int Ln=7;int col=3;
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
											}
										
								}
								// HG-BD(RRVR)5-1,11-7
								if(nombre!=999) {
									int Ln=9;int col=5;
											if (panneau[Ln][col]==" ") {
												
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
											}
										
								}			
								// HG-BD(RRRV)5-1,11-7
								if(nombre!=999) {
									int Ln=11;int col=7;
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&Ln==11) {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
												if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
												}
											}
										
								}
								
								/**
								 * 
								 *verifier J 
								 */
								//horizontale
								if(nombre!=999) {
								 labe:for(int Ln=11;Ln>=1;Ln-=2) {
										for(int col=1;col<=7;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln][col+2]=="J"&&panneau[Ln][col+4]=="J"&&panneau[Ln][col+6]=="J"&&Ln==11) {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
												if(panneau[Ln][col+2]=="J"&&panneau[Ln][col+4]=="J"&&panneau[Ln][col+6]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
												}
											}
										}
									}
								}
									if(nombre!=999) {
								labe:for(int Ln=11;Ln>=1;Ln-=2) {
										for(int col=3;col<=9;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln][col-2]=="J"&&panneau[Ln][col+2]=="J"&&panneau[Ln][col+4]=="J"&&Ln==11) {
													panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
												}
												if(panneau[Ln][col-2]=="J"&&panneau[Ln][col+2]=="J"&&panneau[Ln][col+4]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
												}
											}
										}
									 }
									}
									if(nombre!=999) {
								labe:for(int Ln=11;Ln>=1;Ln-=2) {
										for(int col=5;col<=11;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln][col-4]=="J"&&panneau[Ln][col-2]=="J"&&panneau[Ln][col+2]=="J"&&Ln==11) {
													panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
												}
												if(panneau[Ln][col-4]=="J"&&panneau[Ln][col-2]=="J"&&panneau[Ln][col+2]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
												}
											}
										}
									 }
									}
									if(nombre!=999) {
								labe:for(int Ln=11;Ln>=1;Ln-=2) {
										for(int col=7;col<=13;col+=2) {
											if (panneau[Ln][col]==" ") {
												if(panneau[Ln][col-6]=="J"&&panneau[Ln][col-4]=="J"&&panneau[Ln][col-2]=="J"&&Ln==11) {
													panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
												}
												if(panneau[Ln][col-6]=="J"&&panneau[Ln][col-4]=="J"&&panneau[Ln][col-2]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
													panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
												}
											}
										}
									 }
									}						
									//verticale
									
									if(nombre!=999) {
								  labe:for(int col=1;col<=13;col+=2) {
											for(int Ln=1;Ln<=5;Ln+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+2][col]=="J"&&panneau[Ln+4][col]=="J"&&panneau[Ln+6][col]=="J") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										 }
										}
										
									//BG-HD(VRRR)11-1,1-11
									if(nombre!=999) {
								 labe:for(int Ln=11;Ln>=7;Ln-=2) {
											for(int col=1;col<=5;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&Ln==11) {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									//BG-HD(RVRR)11-1,1-11
									if(nombre!=999) {
									labe:for(int Ln=9;Ln>=5;Ln-=2) {
											for(int col=3;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(RRVR)11-1,1-11
									if(nombre!=999) {
									labe:for(int Ln=7;Ln>=3;Ln-=2) {
											for(int col=5;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(RRRV)11-1,1-11
									if(nombre!=999) {
									labe:for(int Ln=5;Ln>=1;Ln-=2) {
											for(int col=7;col<=11;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+6][col-6]=="J"&&panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									
									//BG-HD(VRRR)11-3,1-13
									if(nombre!=999) {
									labe:for(int Ln=11;Ln>=7;Ln-=2) {
											for(int col=3;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&Ln==11) {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									//BG-HD(RVRR)11-3,1-13
									if(nombre!=999) {
									labe:for(int Ln=9;Ln>=5;Ln-=2) {
											for(int col=5;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(RRVR)11-3,1-13
									if(nombre!=999) {
									labe:for(int Ln=7;Ln>=3;Ln-=2) {
											for(int col=7;col<=11;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(RRRV)11-3,1-13
									if(nombre!=999) {
									labe:for(int Ln=5;Ln>=1;Ln-=2) {
											for(int col=9;col<=13;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+6][col-6]=="J"&&panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(VRRR)9-1,1-9
									if(nombre!=999) {
									labe:for(int Ln=9;Ln>=7;Ln-=2) {
											for(int col=1;col<=3;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									//BG-HD(RVRR)9-1,1-9
									if(nombre!=999) {
								   labe:for(int Ln=7;Ln>=5;Ln-=2) {
											for(int col=3;col<=5;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(RRVR)9-1,1-9
									if(nombre!=999) {
									labe:for(int Ln=5;Ln>=3;Ln-=2) {
											for(int col=5;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(RRRV)9-1,1-9
									if(nombre!=999) {
									labe:for(int Ln=3;Ln>=1;Ln-=2) {
											for(int col=7;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+6][col-6]=="J"&&panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(VRRR)11-5,3-13
									if(nombre!=999) {
									labe:for(int Ln=11;Ln>=9;Ln-=2) {
											for(int col=5;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&Ln==11) {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									//BG-HD(RVRR)11-5,3-13
									if(nombre!=999) {
									labe:for(int Ln=9;Ln>=7;Ln-=2) {
											for(int col=7;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(RRVR)11-5,3-13
									if(nombre!=999) {
									labe:for(int Ln=7;Ln>=5;Ln-=2) {
											for(int col=9;col<=11;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
									//BG-HD(RRRV)11-5,3-13
									if(nombre!=999) {
									labe:for(int Ln=5;Ln>=3;Ln-=2) {
											for(int col=11;col<=13;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+6][col-6]=="J"&&panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
														 panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													
												}
											}
										}
									}
								
									//BG-HD(VRRR)11-7,5-13
									if(nombre!=999) {
										int Ln=11;int col=7;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
													
												}
											
										
									}
									//BG-HD(RVRR)11-7,5-13
									if(nombre!=999) {
										int Ln=9;int col=9;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
													
												}
											
										
									}
									//BG-HD(RRVR)11-7,5-13
									if(nombre!=999) {
										int Ln=7;int col=11;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
													
												}
											
										
									}
									//BG-HD(RRRV)11-7,5-13
									if(nombre!=999) {
										int Ln=5;int col=13;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
													
												}
											
										
									}
									//BG-HD(VRRR)7-1,1-7
									if(nombre!=999) {
										int Ln=7;int col=1;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
													
												}
											
										
									}
									//BG-HD(RVRR)7-1,1-7
									if(nombre!=999) {
										int Ln=5;int col=3;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
													
												}
											
										
									}
									//BG-HD(RRVR)7-1,1-7
									if(nombre!=999) {
										int Ln=3;int col=5;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
													
												}
											
										
									}
									//BG-HD(RRRV)7-1,1-7
									if(nombre!=999) {
										int Ln=1;int col=7;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
													
												}
											
										
									}
									
									/**
									 * HG-BD
									 */
									
									// HG-BD(VRRR)1-1,11-11
									if(nombre!=999) {
									labe:for(int Ln=1;Ln<=5;Ln+=2) {
											for(int col=1;col<=5;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(RVRR)1-1,11-11
									if(nombre!=999) {
									labe:for(int Ln=3;Ln<=7;Ln+=2) {
											for(int col=3;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(RRVR)1-1,11-11
									if(nombre!=999) {
									labe:for(int Ln=5;Ln<=9;Ln+=2) {
											for(int col=5;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}					
									// HG-BD(RRRV)1-1,11-11
									if(nombre!=999) {
										labe:for(int Ln=7;Ln<=11;Ln+=2) {
												for(int col=7;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&Ln==11) {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
									// HG-BD(VRRR)3-1,11-9
									if(nombre!=999) {
									labe:for(int Ln=3;Ln<=5;Ln+=2) {
											for(int col=1;col<=3;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(RVRR)3-1,11-9
									if(nombre!=999) {
									labe:for(int Ln=5;Ln<=7;Ln+=2) {
											for(int col=3;col<=5;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(RRVR)3-1,11-9
									if(nombre!=999) {
									labe:for(int Ln=7;Ln<=9;Ln+=2) {
											for(int col=5;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}					
									// HG-BD(RRRV)3-1,11-9
									if(nombre!=999) {
									labe:for(int Ln=11;Ln>=9;Ln-=2) {
											for(int col=7;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln-6][col-6]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&Ln==11) {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													if(panneau[Ln-6][col-6]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(VRRR)1-3,11-13
									if(nombre!=999) {
									labe:for(int Ln=1;Ln<=5;Ln+=2) {
											for(int col=3;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(RVRR)1-3,11-13
									if(nombre!=999) {
									labe:for(int Ln=3;Ln<=7;Ln+=2) {
											for(int col=5;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(RRVR)1-3,11-13
									if(nombre!=999) {
									labe:for(int Ln=5;Ln<=9;Ln+=2) {
											for(int col=7;col<=11;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}					
									// HG-BD(RRRV)1-3,11-13
									if(nombre!=999) {
									labe:for(int Ln=7;Ln<=11;Ln+=2) {
											for(int col=9;col<=13;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&Ln==11) {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(VRRR)1-5,9-13
									if(nombre!=999) {
									labe:for(int Ln=1;Ln<=3;Ln+=2) {
											for(int col=5;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(RVRR)1-5,9-13
									if(nombre!=999) {
									labe:for(int Ln=3;Ln<=5;Ln+=2) {
											for(int col=7;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(RRVR)1-5,9-13
									if(nombre!=999) {
									labe:for(int Ln=5;Ln<=7;Ln+=2) {
											for(int col=9;col<=11;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}					
									// HG-BD(RRRV)1-5,9-13
									if(nombre!=999) {
									labe:for(int Ln=7;Ln<=9;Ln+=2) {
											for(int col=11;col<=13;col+=2) {
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									}
									// HG-BD(VRRR)1-7,7-13
									if(nombre!=999) {
										int Ln=1;int col=7;
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
												}
											
									}
									// HG-BD(RVRR)1-7,7-13
									if(nombre!=999) {
										int Ln=3;int col=9;
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
												}
											
									}
									// HG-BD(RRVR)1-7,7-13
									if(nombre!=999) {
										int Ln=5;int col=11;
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
												}
											
									}			
									// HG-BD(RRRV)1-7,7-13
									if(nombre!=999) {
										int Ln=7;int col=13;
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
												}
											
									}
									// HG-BD(VRRR)5-1,11-7
									if(nombre!=999) {
										int Ln=5;int col=1;
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
												}
											
									}
									// HG-BD(RVRR)5-1,11-7
									if(nombre!=999) {
										int Ln=7;int col=3;
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
												}
											
									}
									// HG-BD(RRVR)5-1,11-7
									if(nombre!=999) {
										int Ln=9;int col=5;
												if (panneau[Ln][col]==" ") {
													
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
												}
											
									}			
									// HG-BD(RRRV)5-1,11-7
									if(nombre!=999) {
										int Ln=11;int col=7;
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&Ln==11) {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
													if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;
													}
												}
											
									}
									
									/**
									 * 
									 * verifier 3J
									 */
									//horizontale
									
									if(nombre!=999) {
										labe:for(int Ln=11;Ln>=1;Ln-=2) {
											for(int col=1;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln][col+2]=="J"&&panneau[Ln][col+4]=="J"&&Ln==11) {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													if(panneau[Ln][col+2]=="J"&&panneau[Ln][col+4]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
										}
									
									
										if(nombre!=999) {
										labe: for(int Ln=11;Ln>=1;Ln-=2) {
											for(int col=3;col<=11;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln][col-2]=="J"&&panneau[Ln][col+2]=="J"&&Ln==11) {
														panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
													}
													if(panneau[Ln][col-2]=="J"&&panneau[Ln][col+2]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
													}
												}
											}
										 }
										}
										if(nombre!=999) {
											labe: for(int Ln=11;Ln>=1;Ln-=2) {
												for(int col=5;col<=13;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln][col-2]=="J"&&panneau[Ln][col-4]=="J"&&Ln==11) {
															panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
														}
														if(panneau[Ln][col-2]=="J"&&panneau[Ln][col-4]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
														}
													}
												}
											 }
											}
										//verticale
										if(nombre!=999) {
										labe:for(int Ln=7;Ln>=1;Ln-=2) {
												for(int col=1;col<=13;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col]=="J"&&panneau[Ln+4][col]=="J") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
											 	}
											 }
										}
										
										
										//BG-HD(VRR)11-1,1-11
										if(nombre!=999) {
										labe:for(int Ln=11;Ln>=5;Ln-=2) {
												for(int col=1;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&Ln==11) {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										//BG-HD(RVR)11-1,1-11
										if(nombre!=999) {
										labe:for(int Ln=9;Ln>=3;Ln-=2) {
												for(int col=3;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										
										//BG-HD(RRV)11-1,1-11
										if(nombre!=999) {
										labe:for(int Ln=7;Ln>=1;Ln-=2) {
												for(int col=5;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										
										//BG-HD(VRR)11-3,1-13
										if(nombre!=999) {
										labe:for(int Ln=11;Ln>=5;Ln-=2) {
												for(int col=3;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&Ln==11) {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										//BG-HD(RVR)11-3,1-13
										if(nombre!=999) {
										labe:for(int Ln=9;Ln>=3;Ln-=2) {
												for(int col=5;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										
										//BG-HD(RRV)11-3,1-13
										if(nombre!=999) {
										labe:for(int Ln=5;Ln>=1;Ln-=2) {
												for(int col=7;col<=13;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										//BG-HD(VRR)9-1,1-9
										if(nombre!=999) {
										labe:for(int Ln=9;Ln>=5;Ln-=2) {
												for(int col=1;col<=5;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										//BG-HD(RVR)9-1,1-9
										if(nombre!=999) {
										labe:for(int Ln=7;Ln>=3;Ln-=2) {
												for(int col=3;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										
										//BG-HD(RRV)9-1,1-9
										if(nombre!=999) {
										labe:for(int Ln=5;Ln>=1;Ln-=2) {
												for(int col=5;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										//BG-HD(VRR)11-5,3-13
										if(nombre!=999) {
										labe:for(int Ln=11;Ln>=7;Ln-=2) {
												for(int col=5;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&Ln==11) {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										//BG-HD(RVR)11-5,3-13
										if(nombre!=999) {
										labe:for(int Ln=9;Ln>=5;Ln-=2) {
												for(int col=7;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										
										//BG-HD(RRV)11-5,3-13
										if(nombre!=999) {
										labe:for(int Ln=7;Ln>=3;Ln-=2) {
												for(int col=9;col<=13;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
									
										//BG-HD(VRR)11-7,5-13
										if(nombre!=999) {
											labe:for(int Ln=11;Ln>=9;Ln-=2) {
												for(int col=7;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-4][col+4]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
												
											
										}
										//BG-HD(RVR)11-7,5-13
										if(nombre!=999) {
											labe:for(int Ln=9;Ln>=7;Ln-=2) {
												for(int col=9;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
												
											
										}
										
										//BG-HD(RRV)11-7,5-13
										if(nombre!=999) {
											labe:for(int Ln=7;Ln>=5;Ln-=2) {
												for(int col=11;col<=13;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
												
											
										}
										//BG-HD(VRR)7-1,1-7
										if(nombre!=999) {
											labe:for(int Ln=7;Ln>=5;Ln-=2) {
												for(int col=1;col<=3;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
												
											
										}
										//BG-HD(RVR)7-1,1-7
										if(nombre!=999) {
											labe:for(int Ln=5;Ln>=3;Ln-=2) {
												for(int col=3;col<=5;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
												
											
										}
										
										//BG-HD(RRV)7-1,1-7
										if(nombre!=999) {
											labe:for(int Ln=3;Ln>=1;Ln-=2) {
												for(int col=5;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col-2]=="J"&&panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
												
											
										}
										
										/**
										 * HG-BD
										 */
										
										// HG-BD(VRR)1-1,11-11
										if(nombre!=999) {
										labe:for(int Ln=1;Ln<=7;Ln+=2) {
												for(int col=1;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(RVR)1-1,11-11
										if(nombre!=999) {
										labe:for(int Ln=3;Ln<=9;Ln+=2) {
												for(int col=3;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
														
										// HG-BD(RRV)1-1,11-11
										if(nombre!=999) {
										labe:for(int Ln=5;Ln<=11;Ln+=2) {
												for(int col=5;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&Ln==11) {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(VRR)3-1,11-9
										if(nombre!=999) {
										labe:for(int Ln=3;Ln<=7;Ln+=2) {
												for(int col=1;col<=5;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(RVR)3-1,11-9
										if(nombre!=999) {
										labe:for(int Ln=5;Ln<=9;Ln+=2) {
												for(int col=3;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
															
										// HG-BD(RRV)3-1,11-9
										if(nombre!=999) {
										labe:for(int Ln=11;Ln>=7;Ln-=2) {
												for(int col=5;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&Ln==11) {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(VRR)1-3,11-13
										if(nombre!=999) {
										labe:for(int Ln=1;Ln<=7;Ln+=2) {
												for(int col=3;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(RVR)1-3,11-13
										if(nombre!=999) {
										labe:for(int Ln=3;Ln<=9;Ln+=2) {
												for(int col=5;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
														
										// HG-BD(RRV)1-3,11-13
										if(nombre!=999) {
										labe:for(int Ln=5;Ln<=11;Ln+=2) {
												for(int col=7;col<=13;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&Ln==11) {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(VRR)1-5,9-13
										if(nombre!=999) {
										labe:for(int Ln=1;Ln<=5;Ln+=2) {
												for(int col=5;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(RVR)1-5,9-13
										if(nombre!=999) {
										labe:for(int Ln=3;Ln<=7;Ln+=2) {
												for(int col=7;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
													
										// HG-BD(RRV)1-5,9-13
										if(nombre!=999) {
										labe:for(int Ln=5;Ln<=9;Ln+=2) {
												for(int col=9;col<=13;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(VRR)1-7,7-13
										if(nombre!=999) {
											labe:for(int Ln=1;Ln<=3;Ln+=2) {
													for(int col=7;col<=9;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
										// HG-BD(RVR)1-7,7-13
										if(nombre!=999) {
											labe:for(int Ln=3;Ln<=5;Ln+=2) {
													for(int col=9;col<=11;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
												
										
										// HG-BD(RRV)1-7,7-13
										if(nombre!=999) {
											labe:for(int Ln=5;Ln<=7;Ln+=2) {
													for(int col=11;col<=13;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
										// HG-BD(VRR)5-1,11-7
										if(nombre!=999) {
											labe:for(int Ln=5;Ln<=7;Ln+=2) {
													for(int col=1;col<=5;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
										// HG-BD(RVR)5-1,11-7
										if(nombre!=999) {
											labe:for(int Ln=7;Ln<=9;Ln+=2) {
													for(int col=3;col<=5;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
												
												
										// HG-BD(RRV)5-1,11-7
										if(nombre!=999) {
											labe:for(int Ln=9;Ln<=11;Ln+=2) {
													for(int col=5;col<=7;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
										
									
									
									
									/*
									 * 
									 * mettre le pion avoir 3 R linge
									 */
									
									
									//horizontale
									
									if(nombre!=999) {
										labe:for(int Ln=11;Ln>=1;Ln-=2) {
											for(int col=1;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln][col+2]=="R"&&panneau[Ln][col+4]=="R"&&Ln==11) {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
													if(panneau[Ln][col+2]=="R"&&panneau[Ln][col+4]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
										}
									
									
										if(nombre!=999) {
										labe: for(int Ln=11;Ln>=1;Ln-=2) {
											for(int col=3;col<=11;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln][col-2]=="R"&&panneau[Ln][col+2]=="R"&&Ln==11) {
														panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
													}
													if(panneau[Ln][col-2]=="R"&&panneau[Ln][col+2]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
													}
												}
											}
										 }
										}
										if(nombre!=999) {
											labe: for(int Ln=11;Ln>=1;Ln-=2) {
												for(int col=5;col<=13;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln][col-2]=="R"&&panneau[Ln][col-4]=="R"&&Ln==11) {
															panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
														}
														if(panneau[Ln][col-2]=="R"&&panneau[Ln][col-4]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
														}
													}
												}
											 }
											}
										//verticale
										if(nombre!=999) {
										labe:for(int Ln=7;Ln>=1;Ln-=2) {
												for(int col=1;col<=13;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col]=="R"&&panneau[Ln+4][col]=="R") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
											 	}
											 }
										}
										
										
										//BG-HD(VRR)11-1,1-11
										if(nombre!=999) {
										labe:for(int Ln=11;Ln>=5;Ln-=2) {
												for(int col=1;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&Ln==11) {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										//BG-HD(RVR)11-1,1-11
										if(nombre!=999) {
										labe:for(int Ln=9;Ln>=3;Ln-=2) {
												for(int col=3;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										
										//BG-HD(RRV)11-1,1-11
										if(nombre!=999) {
										labe:for(int Ln=7;Ln>=1;Ln-=2) {
												for(int col=5;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										
										//BG-HD(VRR)11-3,1-13
										if(nombre!=999) {
										labe:for(int Ln=11;Ln>=5;Ln-=2) {
												for(int col=3;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&Ln==11) {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										//BG-HD(RVR)11-3,1-13
										if(nombre!=999) {
										labe:for(int Ln=9;Ln>=3;Ln-=2) {
												for(int col=5;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										
										//BG-HD(RRV)11-3,1-13
										if(nombre!=999) {
										labe:for(int Ln=5;Ln>=1;Ln-=2) {
												for(int col=7;col<=13;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										//BG-HD(VRR)9-1,1-9
										if(nombre!=999) {
										labe:for(int Ln=9;Ln>=5;Ln-=2) {
												for(int col=1;col<=5;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										//BG-HD(RVR)9-1,1-9
										if(nombre!=999) {
										labe:for(int Ln=7;Ln>=3;Ln-=2) {
												for(int col=3;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										
										//BG-HD(RRV)9-1,1-9
										if(nombre!=999) {
										labe:for(int Ln=5;Ln>=1;Ln-=2) {
												for(int col=5;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										//BG-HD(VRR)11-5,3-13
										if(nombre!=999) {
										labe:for(int Ln=11;Ln>=7;Ln-=2) {
												for(int col=5;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&Ln==11) {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										//BG-HD(RVR)11-5,3-13
										if(nombre!=999) {
										labe:for(int Ln=9;Ln>=5;Ln-=2) {
												for(int col=7;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										
										//BG-HD(RRV)11-5,3-13
										if(nombre!=999) {
										labe:for(int Ln=7;Ln>=3;Ln-=2) {
												for(int col=9;col<=13;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
									
										//BG-HD(VRR)11-7,5-13
										if(nombre!=999) {
											labe:for(int Ln=11;Ln>=9;Ln-=2) {
												for(int col=7;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-4][col+4]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
												
											
										}
										//BG-HD(RVR)11-7,5-13
										if(nombre!=999) {
											labe:for(int Ln=9;Ln>=7;Ln-=2) {
												for(int col=9;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
												
											
										}
										
										//BG-HD(RRV)11-7,5-13
										if(nombre!=999) {
											labe:for(int Ln=7;Ln>=5;Ln-=2) {
												for(int col=11;col<=13;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
												
											
										}
										//BG-HD(VRR)7-1,1-7
										if(nombre!=999) {
											labe:for(int Ln=7;Ln>=5;Ln-=2) {
												for(int col=1;col<=3;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
												
											
										}
										//BG-HD(RVR)7-1,1-7
										if(nombre!=999) {
											labe:for(int Ln=5;Ln>=3;Ln-=2) {
												for(int col=3;col<=5;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
												
											
										}
										
										//BG-HD(RRV)7-1,1-7
										if(nombre!=999) {
											labe:for(int Ln=3;Ln>=1;Ln-=2) {
												for(int col=5;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col-2]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
												
											
										}
										
										/**
										 * HG-BD
										 */
										
										// HG-BD(VRR)1-1,11-11
										if(nombre!=999) {
										labe:for(int Ln=1;Ln<=7;Ln+=2) {
												for(int col=1;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(RVR)1-1,11-11
										if(nombre!=999) {
										labe:for(int Ln=3;Ln<=9;Ln+=2) {
												for(int col=3;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
														
										// HG-BD(RRV)1-1,11-11
										if(nombre!=999) {
											labe:for(int Ln=5;Ln<=11;Ln+=2) {
													for(int col=5;col<=11;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&Ln==11) {
																panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
															}
															if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
										// HG-BD(VRR)3-1,11-9
										if(nombre!=999) {
										labe:for(int Ln=3;Ln<=7;Ln+=2) {
												for(int col=1;col<=5;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(RVR)3-1,11-9
										if(nombre!=999) {
										labe:for(int Ln=5;Ln<=9;Ln+=2) {
												for(int col=3;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
															
										// HG-BD(RRV)3-1,11-9
										if(nombre!=999) {
										labe:for(int Ln=11;Ln>=7;Ln-=2) {
												for(int col=5;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&Ln==11) {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(VRR)1-3,11-13
										if(nombre!=999) {
										labe:for(int Ln=1;Ln<=7;Ln+=2) {
												for(int col=3;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(RVR)1-3,11-13
										if(nombre!=999) {
										labe:for(int Ln=3;Ln<=9;Ln+=2) {
												for(int col=5;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
														
										// HG-BD(RRV)1-3,11-13
										if(nombre!=999) {
										labe:for(int Ln=5;Ln<=11;Ln+=2) {
												for(int col=7;col<=13;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&Ln==11) {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(VRR)1-5,9-13
										if(nombre!=999) {
										labe:for(int Ln=1;Ln<=5;Ln+=2) {
												for(int col=5;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(RVR)1-5,9-13
										if(nombre!=999) {
										labe:for(int Ln=3;Ln<=7;Ln+=2) {
												for(int col=7;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
													
										// HG-BD(RRV)1-5,9-13
										if(nombre!=999) {
										labe:for(int Ln=5;Ln<=9;Ln+=2) {
												for(int col=9;col<=13;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(VRR)1-7,7-13
										if(nombre!=999) {
											labe:for(int Ln=1;Ln<=3;Ln+=2) {
													for(int col=7;col<=9;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
										// HG-BD(RVR)1-7,7-13
										if(nombre!=999) {
											labe:for(int Ln=3;Ln<=5;Ln+=2) {
													for(int col=9;col<=11;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
												
										
										// HG-BD(RRV)1-7,7-13
										if(nombre!=999) {
											labe:for(int Ln=5;Ln<=7;Ln+=2) {
													for(int col=11;col<=13;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
										// HG-BD(VRR)5-1,11-7
										if(nombre!=999) {
											labe:for(int Ln=5;Ln<=7;Ln+=2) {
													for(int col=1;col<=5;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
										// HG-BD(RVR)5-1,11-7
										if(nombre!=999) {
											labe:for(int Ln=7;Ln<=9;Ln+=2) {
													for(int col=3;col<=5;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
												
												
										// HG-BD(RRV)5-1,11-7
										if(nombre!=999) {
											labe:for(int Ln=9;Ln<=11;Ln+=2) {
													for(int col=5;col<=7;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
										
										/**
										 * 
										 * trouver 2 J
										 */
										
										if(nombre!=999) {
											labe:for(int Ln=11;Ln>=1;Ln-=2) {
												for(int col=1;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln][col+2]=="J"&&Ln==11) {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln][col+2]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
											}
										
										
											
											if(nombre!=999) {
												labe: for(int Ln=11;Ln>=1;Ln-=2) {
													for(int col=3;col<=13;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln][col-2]=="J"&&Ln==11) {
																panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
															}
															if(panneau[Ln][col-2]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
															}
														}
													}
												 }
												}
											
											//verticale
											if(nombre!=999) {
											labe:for(int Ln=9;Ln>=1;Ln-=2) {
													for(int col=1;col<=13;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+2][col]=="J") {
																panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
															}
														}
												 	}
												 }
											}
										
										
										/*
										 * 
										 * mettre le pion avoir 2 R linge
										 */
										
										
										//horizontale
										
										if(nombre!=999) {
											labe:for(int Ln=11;Ln>=1;Ln-=2) {
												for(int col=1;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln][col+2]=="R"&&Ln==11) {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln][col+2]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
											}
										
										
											
											if(nombre!=999) {
												labe: for(int Ln=11;Ln>=1;Ln-=2) {
													for(int col=3;col<=13;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln][col-2]=="R"&&Ln==11) {
																panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
															}
															if(panneau[Ln][col-2]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="R";nombre=999;L=Ln;C=col;break labe;
															}
														}
													}
												 }
												}
											
											//verticale
											if(nombre!=999) {
											labe:for(int Ln=9;Ln>=1;Ln-=2) {
													for(int col=1;col<=13;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+2][col]=="R") {
																panneau[Ln][col]="R";nombre=999;C=col;L=Ln;break labe;
															}
														}
												 	}
												 }
											}
											
											
										
								if(nombre<4) {							
									 L=11;
								     C=(int)(Math.random()*13+1);
								      if(C%2 !=1) {
								    	  C++;
								      }
								     verifier_a: 
								    for(L=11;L>=1;L-=2) {  
									  if(panneau[L][C] == " ") {
										  panneau[L][C]="R";break verifier_a ;
									  }
								    }
								     if(panneau[1][C]!=" ") {
								    	 verifier_c :
												for(C=1;C<=13;C+=2) {
													
													 for(L=11;L>=1;L-=2) {
														 
														  if(panneau[L][C] == " ") {
															  panneau[L][C]="R";break verifier_c;
														  }
															  
														  
													  }
														
													
												}
								     }
								     
									}
							     
								
							     
								  
								
								
								
								int nombrePc=-1;
								int maxPc =0;
								int a=L;
								int b=C;
								String jetonPc= ("R");
								a=L; b=C;nombrePc=-1;
								while(a >= 0 && b >= 0 && panneau[a][b] == jetonPc){ a-=2; b-=2; nombrePc++;}
								a=L; b=C;
								while(a<=11 && b<=13 && panneau[a][b] == jetonPc){ a+=2; b+=2; nombrePc++;}
								if(nombre > maxPc) maxPc= nombrePc;
								
								
								//-->  diagonale HD-BG
								a=L; b=C;nombrePc=-1;
								while(a >= 0 && b <= 13 && panneau[a][b] == jetonPc){ a-=2; b+=2; nombrePc++;}
								a=L; b=C;
								while(a <= 11 && b >=0 && panneau[a][b] == jetonPc){ a+=2; b-=2; nombrePc++;}
								if(nombrePc > maxPc) maxPc= nombrePc;
								
							
								//-->  verticale:
								a=L; b=C;nombrePc=-1;
								while(a >= 0 && panneau[a][b] == jetonPc){ a-=2; nombrePc++;}
								a=L;  
								while(a <= 11 && panneau[a][b] == jetonPc){ a+=2; nombrePc++;}
								if(nombrePc > maxPc) maxPc= nombrePc;
							
								
								//-->  horizontale:
								a=L; b=C;nombrePc=-1;
								while(b >= 0 && panneau[a][b] == jetonPc){ b-=2; nombrePc++;}
								b=C;
								while(b <= 13 && panneau[a][b] == jetonPc){ b+=2; nombrePc++;}
								if(nombrePc > maxPc) maxPc= nombrePc;
								
								
								if(maxPc >= 4){
									gagnant = 2;
									i = 999; break;
								}
								System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
								
						}
								//affichage des résultats:
								// si gagnant == 0 c'est que tout le échiquier s'est remplis sans gagnant, il y a donc égalité
								
								System.out.println();
								System.out.println("#########################");
								System.out.println("    Fin de la partie     ");
								System.out.println("#########################");
								if(gagnant == 0)
									System.out.println("*******EGALITE*******");
								if(gagnant == 1) {
									System.out.println("****"+"Le gagnant est "+nom+"****");
								    System.out.println(     "Felicitations a "+nom+" !"  );
								}
								if(gagnant == 2) {
									System.out.println("****"+"Le gagnant est computer****");
									System.out.println(     "Felicitations a computer!"  );
								}
							    System.out.println(" ");
								System.out.println("____________  Affichage final du panneau______________");
							
								
								for (int x = 0; x < panneau.length; x++){
						            for (int y = 0; y<panneau[x].length; y++){
						                System.out.print(panneau[x][y]);
						            }
						        
							}
								System.out.println(" ");
								System.out.println("_________________________FIN____________________________");
							
				    /**
				     *computer vs player 
				     * 
				     */
				    }else if(ordre.equals("computer")) {
				    	String[][] panneau = {
				                {"\n|-1-|-2-|-3-|-4-|-5-|-6-|-7-|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|"},
				                {"\n| " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | " , " " , " | "},
				                {"\n|---|---|---|---|---|---|---|\n"}
				        };	
				    	
				    	
					      int c=(int)(Math.random()*13+1);
					         if(c%2 !=1) {
					            c++;panneau[11][c]="J";
					        }else {
					        	panneau[11][c]="J";
					        }
					         
					         int gagnant = 0;//Initialisation des variables de gain/perte
								
						    	
				    							
				    	
						/**
						 * Le cycle de jeu de pp commence
						 */
						for(int i = 1 ; i <= 21 ; i++){  
							
							//affichage du échiquier:
							System.out.println("Tour " + i + ", Etat du echiquier :");
							//affichage du échiquier:for(int loop = 0 ; loop < 7 ; loop++)
							
							 for (int x = 0; x < panneau.length; x++){
						            for (int y = 0; y<panneau[x].length; y++){
						                System.out.print(panneau[x][y]);
						            }
						        
							}
							 System.out.println("Tour du "+nom );//"Jaune" = player  /  "Rouge"  = computeur
								System.out.println("Entrez le numero de la colonne entre 1 et 7 SVP___");
								boolean placement = false;
								int colonne =-1;//Initialiser un numéro de colonne inexistant
								while(!placement){ //la condiction de la boucle est true
									colonne = -1;
									String ligne = scanner.nextLine();
									//vérification que la ligne est un entier entre 1 et 7:
									try{
										colonne = Integer.valueOf(ligne);
										
										if(colonne >= 1 && colonne <= 7){
											if(panneau[1][colonne*2-1] != " "){ //Une situation où une colonne est toute remplie
												System.out.println("Colonne pleine, Veuillez saisir à nouveau le nombre de colonnes___");
											} else {
												placement = true;
											}
										} else {
											System.out.println("Nombre incorrect, Veuillez saisir à nouveau le nombre de colonnes___");
										}
										//Déclarations de résolution d'erreurs	
									}catch(Exception e){System.out.println("Nombre incorrect, Veuillez saisir à nouveau le nombre de colonnes___");}
							}
								
								//placement du jeton:
								int rang = 11;
								while(panneau[rang][colonne*2-1] != " "){
									rang=rang-2;//Observez s'il y a une pièce à un point, si oui, passez à la ligne précédente de la colonne.
								}
								panneau[rang][colonne*2-1] = "R";//Placement des pièces
								
								String jeton= ("R");
								int nombre=0;
								int L=rang;
								int C=colonne*2-1;
								int max = 0;
								//-->  diagonale HG-BD
								L=rang; C=colonne*2-1;nombre=-1;
								while(L >= 0 && C >= 0 && panneau[L][C] == jeton){ L-=2; C-=2; nombre++;}
								L=rang; C=colonne*2-1;
								while(L<=11 && C<=13 && panneau[L][C] == jeton){ L+=2; C+=2; nombre++;}
								if(nombre > max) max= nombre;
								
								
								//-->  diagonale HD-BG
								L=rang; C=colonne*2-1;nombre=-1;
								while(L >= 0 && C <= 13 && panneau[L][C] == jeton){ L-=2; C+=2; nombre++;}
								L=rang; C=colonne*2-1;
								while(L <= 11 && C >=0 && panneau[L][C] == jeton){ L+=2; C-=2; nombre++;}
								if(nombre > max) max= nombre;
								
							
								//-->  verticale:
								L=rang; C=colonne*2-1; nombre=-1;
								while(L >= 0 && panneau[L][C] == jeton){ L-=2; nombre++;}
								L=rang;  
								while(L <= 11 && panneau[L][C] == jeton){ L+=2; nombre++;}
								if(nombre > max) max= nombre;
							
								
								//-->  horizontale:
								L=rang; C=colonne*2-1;nombre=-1;
								while(C >= 0 && panneau[L][C] == jeton){ C-=2; nombre++;}
								 C=colonne*2-1;
								while(C <= 13 && panneau[L][C] == jeton){ C+=2; nombre++;}
								if(nombre > max) max= nombre;
								
								if(max >= 4){
									gagnant = 1;
									i = 999; break;
								}
								/**
								 * 
								 *verifier J 
								 */
								//horizontale
								
									 labe:for(int Ln=11;Ln>=1;Ln-=2) {
											for(int col=1;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln][col+2]=="J"&&panneau[Ln][col+4]=="J"&&panneau[Ln][col+6]=="J"&&Ln==11) {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
													if(panneau[Ln][col+2]=="J"&&panneau[Ln][col+4]=="J"&&panneau[Ln][col+6]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
									
										if(nombre!=999) {
									labe:for(int Ln=11;Ln>=1;Ln-=2) {
											for(int col=3;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln][col-2]=="J"&&panneau[Ln][col+2]=="J"&&panneau[Ln][col+4]=="J"&&Ln==11) {
														panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
													}
													if(panneau[Ln][col-2]=="J"&&panneau[Ln][col+2]=="J"&&panneau[Ln][col+4]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
													}
												}
											}
										 }
										}
										if(nombre!=999) {
									labe:for(int Ln=11;Ln>=1;Ln-=2) {
											for(int col=5;col<=11;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln][col-4]=="J"&&panneau[Ln][col-2]=="J"&&panneau[Ln][col+2]=="J"&&Ln==11) {
														panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
													}
													if(panneau[Ln][col-4]=="J"&&panneau[Ln][col-2]=="J"&&panneau[Ln][col+2]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
													}
												}
											}
										 }
										}
										if(nombre!=999) {
									labe:for(int Ln=11;Ln>=1;Ln-=2) {
											for(int col=7;col<=13;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln][col-6]=="J"&&panneau[Ln][col-4]=="J"&&panneau[Ln][col-2]=="J"&&Ln==11) {
														panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
													}
													if(panneau[Ln][col-6]=="J"&&panneau[Ln][col-4]=="J"&&panneau[Ln][col-2]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
													}
												}
											}
										 }
										}						
										//verticale
										
										if(nombre!=999) {
									  labe:for(int col=1;col<=13;col+=2) {
												for(int Ln=1;Ln<=5;Ln+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col]=="J"&&panneau[Ln+4][col]=="J"&&panneau[Ln+6][col]=="J") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											 }
											}
											
										//BG-HD(VRRR)11-1,1-11
										if(nombre!=999) {
									 labe:for(int Ln=11;Ln>=7;Ln-=2) {
												for(int col=1;col<=5;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&Ln==11) {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										//BG-HD(RVRR)11-1,1-11
										if(nombre!=999) {
										labe:for(int Ln=9;Ln>=5;Ln-=2) {
												for(int col=3;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										//BG-HD(RRVR)11-1,1-11
										if(nombre!=999) {
										labe:for(int Ln=7;Ln>=3;Ln-=2) {
												for(int col=5;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										//BG-HD(RRRV)11-1,1-11
										if(nombre!=999) {
										labe:for(int Ln=5;Ln>=1;Ln-=2) {
												for(int col=7;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+6][col-6]=="J"&&panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										
										//BG-HD(VRRR)11-3,1-13
										if(nombre!=999) {
										labe:for(int Ln=11;Ln>=7;Ln-=2) {
												for(int col=3;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&Ln==11) {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										//BG-HD(RVRR)11-3,1-13
										if(nombre!=999) {
										labe:for(int Ln=9;Ln>=5;Ln-=2) {
												for(int col=5;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										//BG-HD(RRVR)11-3,1-13
										if(nombre!=999) {
										labe:for(int Ln=7;Ln>=3;Ln-=2) {
												for(int col=7;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										//BG-HD(RRRV)11-3,1-13
										if(nombre!=999) {
										labe:for(int Ln=5;Ln>=1;Ln-=2) {
												for(int col=9;col<=13;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+6][col-6]=="J"&&panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										//BG-HD(VRRR)9-1,1-9
										if(nombre!=999) {
										labe:for(int Ln=9;Ln>=7;Ln-=2) {
												for(int col=1;col<=3;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										//BG-HD(RVRR)9-1,1-9
										if(nombre!=999) {
									   labe:for(int Ln=7;Ln>=5;Ln-=2) {
												for(int col=3;col<=5;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										//BG-HD(RRVR)9-1,1-9
										if(nombre!=999) {
										labe:for(int Ln=5;Ln>=3;Ln-=2) {
												for(int col=5;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										//BG-HD(RRRV)9-1,1-9
										if(nombre!=999) {
										labe:for(int Ln=3;Ln>=1;Ln-=2) {
												for(int col=7;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+6][col-6]=="J"&&panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										//BG-HD(VRRR)11-5,3-13
										if(nombre!=999) {
										labe:for(int Ln=11;Ln>=9;Ln-=2) {
												for(int col=5;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&Ln==11) {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										//BG-HD(RVRR)11-5,3-13
										if(nombre!=999) {
										labe:for(int Ln=9;Ln>=7;Ln-=2) {
												for(int col=7;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										//BG-HD(RRVR)11-5,3-13
										if(nombre!=999) {
										labe:for(int Ln=7;Ln>=5;Ln-=2) {
												for(int col=9;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										//BG-HD(RRRV)11-5,3-13
										if(nombre!=999) {
										labe:for(int Ln=5;Ln>=3;Ln-=2) {
												for(int col=11;col<=13;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+6][col-6]=="J"&&panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
															 panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe; 
														}
														
													}
												}
											}
										}
									
										//BG-HD(VRRR)11-7,5-13
										if(nombre!=999) {
											int Ln=11;int col=7;
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
														
													}
												
											
										}
										//BG-HD(RVRR)11-7,5-13
										if(nombre!=999) {
											int Ln=9;int col=9;
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
														
													}
												
											
										}
										//BG-HD(RRVR)11-7,5-13
										if(nombre!=999) {
											int Ln=7;int col=11;
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
														
													}
												
											
										}
										//BG-HD(RRRV)11-7,5-13
										if(nombre!=999) {
											int Ln=5;int col=13;
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
														
													}
												
											
										}
										//BG-HD(VRRR)7-1,1-7
										if(nombre!=999) {
											int Ln=7;int col=1;
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln-6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
														
													}
												
											
										}
										//BG-HD(RVRR)7-1,1-7
										if(nombre!=999) {
											int Ln=5;int col=3;
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
														
													}
												
											
										}
										//BG-HD(RRVR)7-1,1-7
										if(nombre!=999) {
											int Ln=3;int col=5;
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
														
													}
												
											
										}
										//BG-HD(RRRV)7-1,1-7
										if(nombre!=999) {
											int Ln=1;int col=7;
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
														
													}
												
											
										}
										
										/**
										 * HG-BD
										 */
										
										// HG-BD(VRRR)1-1,11-11
										if(nombre!=999) {
										labe:for(int Ln=1;Ln<=5;Ln+=2) {
												for(int col=1;col<=5;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(RVRR)1-1,11-11
										if(nombre!=999) {
										labe:for(int Ln=3;Ln<=7;Ln+=2) {
												for(int col=3;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(RRVR)1-1,11-11
										if(nombre!=999) {
										labe:for(int Ln=5;Ln<=9;Ln+=2) {
												for(int col=5;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}					
										// HG-BD(RRRV)1-1,11-11
										if(nombre!=999) {
											labe:for(int Ln=7;Ln<=11;Ln+=2) {
													for(int col=7;col<=11;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&Ln==11) {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
										// HG-BD(VRRR)3-1,11-9
										if(nombre!=999) {
										labe:for(int Ln=3;Ln<=5;Ln+=2) {
												for(int col=1;col<=3;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(RVRR)3-1,11-9
										if(nombre!=999) {
										labe:for(int Ln=5;Ln<=7;Ln+=2) {
												for(int col=3;col<=5;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(RRVR)3-1,11-9
										if(nombre!=999) {
										labe:for(int Ln=7;Ln<=9;Ln+=2) {
												for(int col=5;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}					
										// HG-BD(RRRV)3-1,11-9
										if(nombre!=999) {
										labe:for(int Ln=11;Ln>=9;Ln-=2) {
												for(int col=7;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-6][col-6]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&Ln==11) {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln-6][col-6]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(VRRR)1-3,11-13
										if(nombre!=999) {
										labe:for(int Ln=1;Ln<=5;Ln+=2) {
												for(int col=3;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(RVRR)1-3,11-13
										if(nombre!=999) {
										labe:for(int Ln=3;Ln<=7;Ln+=2) {
												for(int col=5;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(RRVR)1-3,11-13
										if(nombre!=999) {
										labe:for(int Ln=5;Ln<=9;Ln+=2) {
												for(int col=7;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}					
										// HG-BD(RRRV)1-3,11-13
										if(nombre!=999) {
										labe:for(int Ln=7;Ln<=11;Ln+=2) {
												for(int col=9;col<=13;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&Ln==11) {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(VRRR)1-5,9-13
										if(nombre!=999) {
										labe:for(int Ln=1;Ln<=3;Ln+=2) {
												for(int col=5;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(RVRR)1-5,9-13
										if(nombre!=999) {
										labe:for(int Ln=3;Ln<=5;Ln+=2) {
												for(int col=7;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(RRVR)1-5,9-13
										if(nombre!=999) {
										labe:for(int Ln=5;Ln<=7;Ln+=2) {
												for(int col=9;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}					
										// HG-BD(RRRV)1-5,9-13
										if(nombre!=999) {
										labe:for(int Ln=7;Ln<=9;Ln+=2) {
												for(int col=11;col<=13;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(VRRR)1-7,7-13
										if(nombre!=999) {
											int Ln=1;int col=7;
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
													}
												
										}
										// HG-BD(RVRR)1-7,7-13
										if(nombre!=999) {
											int Ln=3;int col=9;
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
													}
												
										}
										// HG-BD(RRVR)1-7,7-13
										if(nombre!=999) {
											int Ln=5;int col=11;
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
													}
												
										}			
										// HG-BD(RRRV)1-7,7-13
										if(nombre!=999) {
											int Ln=7;int col=13;
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
													}
												
										}
										// HG-BD(VRRR)5-1,11-7
										if(nombre!=999) {
											int Ln=5;int col=1;
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+6][col+6]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
													}
												
										}
										// HG-BD(RVRR)5-1,11-7
										if(nombre!=999) {
											int Ln=7;int col=3;
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
													}
												
										}
										// HG-BD(RRVR)5-1,11-7
										if(nombre!=999) {
											int Ln=9;int col=5;
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
													}
												
										}			
										// HG-BD(RRRV)5-1,11-7
										if(nombre!=999) {
											int Ln=11;int col=7;
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&Ln==11) {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
														if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln-6][col-6]=="J"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
													}
												
										}
								/**
								 * 
								 * verifier JOUER
								 * 
								 
								 */
								//horizontale
										if(nombre!=999) {
										labe:for(int Ln=11;Ln>=1;Ln-=2) {
											for(int col=1;col<=7;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln][col+2]=="R"&&panneau[Ln][col+4]=="R"&&panneau[Ln][col+6]=="R"&&Ln==11) {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
													if(panneau[Ln][col+2]=="R"&&panneau[Ln][col+4]=="R"&&panneau[Ln][col+6]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
													}
												}
											}
										}
										}
										if(nombre!=999) {
									labe: for(int Ln=11;Ln>=1;Ln-=2) {
											for(int col=3;col<=9;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln][col-2]=="R"&&panneau[Ln][col+2]=="R"&&panneau[Ln][col+4]=="R"&&Ln==11) {
														panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
													}
													if(panneau[Ln][col-2]=="R"&&panneau[Ln][col+2]=="R"&&panneau[Ln][col+4]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
													}
												}
											}
										 }
										}
										if(nombre!=999) {
									labe: for(int Ln=11;Ln>=1;Ln-=2) {
											for(int col=5;col<=11;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln][col-4]=="R"&&panneau[Ln][col-2]=="R"&&panneau[Ln][col+2]=="R"&&Ln==11) {
														panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
													}
													if(panneau[Ln][col-4]=="R"&&panneau[Ln][col-2]=="R"&&panneau[Ln][col+2]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
													}
												}
											}
										 }
										}
										if(nombre!=999) {
									labe:for(int Ln=11;Ln>=1;Ln-=2) {
											for(int col=7;col<=13;col+=2) {
												if (panneau[Ln][col]==" ") {
													if(panneau[Ln][col-6]=="R"&&panneau[Ln][col-4]=="R"&&panneau[Ln][col-2]=="R"&&Ln==11) {
														panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
													}
													if(panneau[Ln][col-6]=="R"&&panneau[Ln][col-4]=="R"&&panneau[Ln][col-2]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
														panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
													}
												}
											}
										 }
										}
										//verticale
										
										if(nombre!=999) {
										 labe:for(int col=1;col<=13;col+=2) {
												for(int Ln=1;Ln<=5;Ln+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col]=="R"&&panneau[Ln+4][col]=="R"&&panneau[Ln+6][col]=="R") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											 }
											}
											
										//BG-HD(VRRR)11-1,1-11
										if(nombre!=999) {
										labe:for(int Ln=11;Ln>=7;Ln-=2) {
												for(int col=1;col<=5;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&Ln==11) {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										//BG-HD(RVRR)11-1,1-11
										if(nombre!=999) {
										labe:for(int Ln=9;Ln>=5;Ln-=2) {
												for(int col=3;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										//BG-HD(RRVR)11-1,1-11
										if(nombre!=999) {
										labe:for(int Ln=7;Ln>=3;Ln-=2) {
												for(int col=5;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										//BG-HD(RRRV)11-1,1-11
										if(nombre!=999) {
										labe:for(int Ln=5;Ln>=1;Ln-=2) {
												for(int col=7;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										
										//BG-HD(VRRR)11-3,1-13
										if(nombre!=999) {
										labe:for(int Ln=11;Ln>=7;Ln-=2) {
												for(int col=3;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&Ln==11) {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										//BG-HD(RVRR)11-3,1-13
										if(nombre!=999) {
										labe:for(int Ln=9;Ln>=5;Ln-=2) {
												for(int col=5;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										//BG-HD(RRVR)11-3,1-13
										if(nombre!=999) {
										labe:for(int Ln=7;Ln>=3;Ln-=2) {
												for(int col=7;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										//BG-HD(RRRV)11-3,1-13
										if(nombre!=999) {
										labe:for(int Ln=5;Ln>=1;Ln-=2) {
												for(int col=9;col<=13;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										//BG-HD(VRRR)9-1,1-9
										if(nombre!=999) {
										labe:for(int Ln=9;Ln>=7;Ln-=2) {
												for(int col=1;col<=3;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										//BG-HD(RVRR)9-1,1-9
										if(nombre!=999) {
										labe:for(int Ln=7;Ln>=5;Ln-=2) {
												for(int col=3;col<=5;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										//BG-HD(RRVR)9-1,1-9
										if(nombre!=999) {
										labe:for(int Ln=5;Ln>=3;Ln-=2) {
												for(int col=5;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										//BG-HD(RRRV)9-1,1-9
										if(nombre!=999) {
										labe:for(int Ln=3;Ln>=1;Ln-=2) {
												for(int col=7;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										//BG-HD(VRRR)11-5,3-13
										if(nombre!=999) {
										labe:for(int Ln=11;Ln>=9;Ln-=2) {
												for(int col=5;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&Ln==11) {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										//BG-HD(RVRR)11-5,3-13
										if(nombre!=999) {
										labe:for(int Ln=9;Ln>=7;Ln-=2) {
												for(int col=7;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										//BG-HD(RRVR)11-5,3-13
										if(nombre!=999) {
										labe:for(int Ln=7;Ln>=5;Ln-=2) {
												for(int col=9;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
										//BG-HD(RRRV)11-5,3-13
										if(nombre!=999) {
										labe:for(int Ln=5;Ln>=3;Ln-=2) {
												for(int col=11;col<=13;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														
													}
												}
											}
										}
									
										//BG-HD(VRRR)11-7,5-13
										if(nombre!=999) {
											int Ln=11;int col=7;
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
														
													}
												
											
										}
										//BG-HD(RVRR)11-7,5-13
										if(nombre!=999) {
											int Ln=9;int col=9;
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
														
													}
												
											
										}
										//BG-HD(RRVR)11-7,5-13
										if(nombre!=999) {
											int Ln=7;int col=11;
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
														
													}
												
											
										}
										//BG-HD(RRRV)11-7,5-13
										if(nombre!=999) {
											int Ln=5;int col=13;
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
														
													}
												
											
										}
										//BG-HD(VRRR)7-1,1-7
										if(nombre!=999) {
											int Ln=7;int col=1;
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln-6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
														
													}
												
											
										}
										//BG-HD(RVRR)7-1,1-7
										if(nombre!=999) {
											int Ln=5;int col=3;
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
														
													}
												
											
										}
										//BG-HD(RRVR)7-1,1-7
										if(nombre!=999) {
											int Ln=3;int col=5;
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
														
													}
												
											
										}
										//BG-HD(RRRV)7-1,1-7
										if(nombre!=999) {
											int Ln=1;int col=7;
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln+6][col-6]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
														
													}
												
											
										}
										
										/**
										 * HG-BD
										 */
										
										// HG-BD(VRRR)1-1,11-11
										if(nombre!=999) {
										labe:for(int Ln=1;Ln<=5;Ln+=2) {
												for(int col=1;col<=5;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(RVRR)1-1,11-11
										if(nombre!=999) {
										labe:for(int Ln=3;Ln<=7;Ln+=2) {
												for(int col=3;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(RRVR)1-1,11-11
										if(nombre!=999) {
										labe:for(int Ln=5;Ln<=9;Ln+=2) {
												for(int col=5;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}					
										// HG-BD(RRRV)1-1,11-11
										if(nombre!=999) {
											labe:for(int Ln=7;Ln<=11;Ln+=2) {
													for(int col=7;col<=11;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&Ln==11) {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
										// HG-BD(VRRR)3-1,11-9
										if(nombre!=999) {
										labe:for(int Ln=3;Ln<=5;Ln+=2) {
												for(int col=1;col<=3;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(RVRR)3-1,11-9
										if(nombre!=999) {
										labe:for(int Ln=5;Ln<=7;Ln+=2) {
												for(int col=3;col<=5;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(RRVR)3-1,11-9
										if(nombre!=999) {
										labe:for(int Ln=7;Ln<=9;Ln+=2) {
												for(int col=5;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}					
										// HG-BD(RRRV)3-1,11-9
										if(nombre!=999) {
										labe:for(int Ln=11;Ln>=9;Ln-=2) {
												for(int col=7;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-6][col-6]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&Ln==11) {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln-6][col-6]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(VRRR)1-3,11-13
										if(nombre!=999) {
										labe:for(int Ln=1;Ln<=5;Ln+=2) {
												for(int col=3;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(RVRR)1-3,11-13
										if(nombre!=999) {
										labe:for(int Ln=3;Ln<=7;Ln+=2) {
												for(int col=5;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(RRVR)1-3,11-13
										if(nombre!=999) {
										labe:for(int Ln=5;Ln<=9;Ln+=2) {
												for(int col=7;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}					
										// HG-BD(RRRV)1-3,11-13
										if(nombre!=999) {
										labe:for(int Ln=7;Ln<=11;Ln+=2) {
												for(int col=9;col<=13;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&Ln==11) {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(VRRR)1-5,9-13
										if(nombre!=999) {
										labe:for(int Ln=1;Ln<=3;Ln+=2) {
												for(int col=5;col<=7;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(RVRR)1-5,9-13
										if(nombre!=999) {
										labe:for(int Ln=3;Ln<=5;Ln+=2) {
												for(int col=7;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(RRVR)1-5,9-13
										if(nombre!=999) {
										labe:for(int Ln=5;Ln<=7;Ln+=2) {
												for(int col=9;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}					
										// HG-BD(RRRV)1-5,9-13
										if(nombre!=999) {
										labe:for(int Ln=7;Ln<=9;Ln+=2) {
												for(int col=11;col<=13;col+=2) {
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
										}
										// HG-BD(VRRR)1-7,7-13
										if(nombre!=999) {
											int Ln=1;int col=7;
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
													}
												
										}
										// HG-BD(RVRR)1-7,7-13
										if(nombre!=999) {
											int Ln=3;int col=9;
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
													}
												
										}
										// HG-BD(RRVR)1-7,7-13
										if(nombre!=999) {
											int Ln=5;int col=11;
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
													}
												
										}			
										// HG-BD(RRRV)1-7,7-13
										if(nombre!=999) {
											int Ln=7;int col=13;
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
													}
												
										}
										// HG-BD(VRRR)5-1,11-7
										if(nombre!=999) {
											int Ln=5;int col=1;
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
													}
												
										}
										// HG-BD(RVRR)5-1,11-7
										if(nombre!=999) {
											int Ln=7;int col=3;
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
													}
												
										}
										// HG-BD(RRVR)5-1,11-7
										if(nombre!=999) {
											int Ln=9;int col=5;
													if (panneau[Ln][col]==" ") {
														
														if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
													}
												
										}			
										// HG-BD(RRRV)5-1,11-7
										if(nombre!=999) {
											int Ln=11;int col=7;
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&Ln==11) {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
														if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln-6][col-6]=="R"&&panneau[Ln+6][col+6]=="R"&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;
														}
													}
												
										}
                                  
										
										/**
										 * 
										 *trouver 3R
										 */
										

										//horizontale
										
										if(nombre!=999) {
											labe:for(int Ln=11;Ln>=1;Ln-=2) {
												for(int col=1;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln][col+2]=="R"&&panneau[Ln][col+4]=="R"&&Ln==11) {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln][col+2]=="R"&&panneau[Ln][col+4]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
											}
										
										
											if(nombre!=999) {
											labe: for(int Ln=11;Ln>=1;Ln-=2) {
												for(int col=3;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln][col-2]=="R"&&panneau[Ln][col+2]=="R"&&Ln==11) {
															panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
														}
														if(panneau[Ln][col-2]=="R"&&panneau[Ln][col+2]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
														}
													}
												}
											 }
											}
											if(nombre!=999) {
												labe: for(int Ln=11;Ln>=1;Ln-=2) {
													for(int col=5;col<=13;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln][col-2]=="R"&&panneau[Ln][col-4]=="R"&&Ln==11) {
																panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
															}
															if(panneau[Ln][col-2]=="R"&&panneau[Ln][col-4]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
															}
														}
													}
												 }
												}
											//verticale
											if(nombre!=999) {
											labe:for(int Ln=7;Ln>=1;Ln-=2) {
													for(int col=1;col<=13;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+2][col]=="R"&&panneau[Ln+4][col]=="R") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
												 	}
												 }
											}
											
											
											//BG-HD(VRR)11-1,1-11
											if(nombre!=999) {
											labe:for(int Ln=11;Ln>=5;Ln-=2) {
													for(int col=1;col<=7;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&Ln==11) {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
											//BG-HD(RVR)11-1,1-11
											if(nombre!=999) {
											labe:for(int Ln=9;Ln>=3;Ln-=2) {
													for(int col=3;col<=9;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
											}
											
											//BG-HD(RRV)11-1,1-11
											if(nombre!=999) {
											labe:for(int Ln=7;Ln>=1;Ln-=2) {
													for(int col=5;col<=11;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
											}
											
											//BG-HD(VRR)11-3,1-13
											if(nombre!=999) {
											labe:for(int Ln=11;Ln>=5;Ln-=2) {
													for(int col=3;col<=9;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&Ln==11) {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
											//BG-HD(RVR)11-3,1-13
											if(nombre!=999) {
											labe:for(int Ln=9;Ln>=3;Ln-=2) {
													for(int col=5;col<=11;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
											}
											
											//BG-HD(RRV)11-3,1-13
											if(nombre!=999) {
											labe:for(int Ln=5;Ln>=1;Ln-=2) {
													for(int col=7;col<=13;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
											}
											//BG-HD(VRR)9-1,1-9
											if(nombre!=999) {
											labe:for(int Ln=9;Ln>=5;Ln-=2) {
													for(int col=1;col<=5;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
											//BG-HD(RVR)9-1,1-9
											if(nombre!=999) {
											labe:for(int Ln=7;Ln>=3;Ln-=2) {
													for(int col=3;col<=7;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
											}
											
											//BG-HD(RRV)9-1,1-9
											if(nombre!=999) {
											labe:for(int Ln=5;Ln>=1;Ln-=2) {
													for(int col=5;col<=9;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
											}
											//BG-HD(VRR)11-5,3-13
											if(nombre!=999) {
											labe:for(int Ln=11;Ln>=7;Ln-=2) {
													for(int col=5;col<=9;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&Ln==11) {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
											//BG-HD(RVR)11-5,3-13
											if(nombre!=999) {
											labe:for(int Ln=9;Ln>=5;Ln-=2) {
													for(int col=7;col<=11;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
											}
											
											//BG-HD(RRV)11-5,3-13
											if(nombre!=999) {
											labe:for(int Ln=7;Ln>=3;Ln-=2) {
													for(int col=9;col<=13;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
											}
										
											//BG-HD(VRR)11-7,5-13
											if(nombre!=999) {
												labe:for(int Ln=11;Ln>=9;Ln-=2) {
													for(int col=7;col<=9;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln-4][col+4]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
													
												
											}
											//BG-HD(RVR)11-7,5-13
											if(nombre!=999) {
												labe:for(int Ln=9;Ln>=7;Ln-=2) {
													for(int col=9;col<=11;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
													
												
											}
											
											//BG-HD(RRV)11-7,5-13
											if(nombre!=999) {
												labe:for(int Ln=7;Ln>=5;Ln-=2) {
													for(int col=11;col<=13;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col-2]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
													
												
											}
											//BG-HD(VRR)7-1,1-7
											if(nombre!=999) {
												labe:for(int Ln=7;Ln>=5;Ln-=2) {
													for(int col=1;col<=3;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln-2][col+2]=="R"&&panneau[Ln-4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
													
												
											}
											//BG-HD(RVR)7-1,1-7
											if(nombre!=999) {
												labe:for(int Ln=5;Ln>=3;Ln-=2) {
													for(int col=3;col<=5;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+2][col-2]=="R"&&panneau[Ln-2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
													
												
											}
											
											//BG-HD(RRV)7-1,1-7
											if(nombre!=999) {
												labe:for(int Ln=3;Ln>=1;Ln-=2) {
													for(int col=5;col<=7;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+2][col-2]=="R"&&panneau[Ln+4][col-4]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
													
												
											}
											
											/**
											 * HG-BD
											 */
											
											// HG-BD(VRR)1-1,11-11
											if(nombre!=999) {
											labe:for(int Ln=1;Ln<=7;Ln+=2) {
													for(int col=1;col<=7;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
											// HG-BD(RVR)1-1,11-11
											if(nombre!=999) {
											labe:for(int Ln=3;Ln<=9;Ln+=2) {
													for(int col=3;col<=9;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
															
											// HG-BD(RRV)1-1,11-11
											if(nombre!=999) {
												labe:for(int Ln=5;Ln<=11;Ln+=2) {
														for(int col=5;col<=11;col+=2) {
															if (panneau[Ln][col]==" ") {
																
																if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&Ln==11) {
																	panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
																}
																if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
																	panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
																}
															}
														}
													}
												}
											// HG-BD(VRR)3-1,11-9
											if(nombre!=999) {
											labe:for(int Ln=3;Ln<=7;Ln+=2) {
													for(int col=1;col<=5;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
											// HG-BD(RVR)3-1,11-9
											if(nombre!=999) {
											labe:for(int Ln=5;Ln<=9;Ln+=2) {
													for(int col=3;col<=7;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
																
											// HG-BD(RRV)3-1,11-9
											if(nombre!=999) {
											labe:for(int Ln=11;Ln>=7;Ln-=2) {
													for(int col=5;col<=9;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&Ln==11) {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															if(panneau[Ln-4][col-4]=="R"&&panneau[Ln-2][col-2]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
											// HG-BD(VRR)1-3,11-13
											if(nombre!=999) {
											labe:for(int Ln=1;Ln<=7;Ln+=2) {
													for(int col=3;col<=9;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
											// HG-BD(RVR)1-3,11-13
											if(nombre!=999) {
											labe:for(int Ln=3;Ln<=9;Ln+=2) {
													for(int col=5;col<=11;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
															
											// HG-BD(RRV)1-3,11-13
											if(nombre!=999) {
											labe:for(int Ln=5;Ln<=11;Ln+=2) {
													for(int col=7;col<=13;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&Ln==11) {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
											// HG-BD(VRR)1-5,9-13
											if(nombre!=999) {
											labe:for(int Ln=1;Ln<=5;Ln+=2) {
													for(int col=5;col<=9;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
											// HG-BD(RVR)1-5,9-13
											if(nombre!=999) {
											labe:for(int Ln=3;Ln<=7;Ln+=2) {
													for(int col=7;col<=11;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
														
											// HG-BD(RRV)1-5,9-13
											if(nombre!=999) {
											labe:for(int Ln=5;Ln<=9;Ln+=2) {
													for(int col=9;col<=13;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
											// HG-BD(VRR)1-7,7-13
											if(nombre!=999) {
												labe:for(int Ln=1;Ln<=3;Ln+=2) {
														for(int col=7;col<=9;col+=2) {
															if (panneau[Ln][col]==" ") {
																
																if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
																	panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
																}
															}
														}
													}
												}
											// HG-BD(RVR)1-7,7-13
											if(nombre!=999) {
												labe:for(int Ln=3;Ln<=5;Ln+=2) {
														for(int col=9;col<=11;col+=2) {
															if (panneau[Ln][col]==" ") {
																
																if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
																	panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
																}
															}
														}
													}
												}
													
											
											// HG-BD(RRV)1-7,7-13
											if(nombre!=999) {
												labe:for(int Ln=5;Ln<=7;Ln+=2) {
														for(int col=11;col<=13;col+=2) {
															if (panneau[Ln][col]==" ") {
																
																if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln+2][col]!=" ") {
																	panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
																}
															}
														}
													}
												}
											// HG-BD(VRR)5-1,11-7
											if(nombre!=999) {
												labe:for(int Ln=5;Ln<=7;Ln+=2) {
														for(int col=1;col<=5;col+=2) {
															if (panneau[Ln][col]==" ") {
																
																if(panneau[Ln+2][col+2]=="R"&&panneau[Ln+4][col+4]=="R"&&panneau[Ln+2][col]!=" ") {
																	panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
																}
															}
														}
													}
												}
											// HG-BD(RVR)5-1,11-7
											if(nombre!=999) {
												labe:for(int Ln=7;Ln<=9;Ln+=2) {
														for(int col=3;col<=5;col+=2) {
															if (panneau[Ln][col]==" ") {
																
																if(panneau[Ln-2][col-2]=="R"&&panneau[Ln+2][col+2]=="R"&&panneau[Ln+2][col]!=" ") {
																	panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
																}
															}
														}
													}
												}
													
													
											// HG-BD(RRV)5-1,11-7
											if(nombre!=999) {
												labe:for(int Ln=9;Ln<=11;Ln+=2) {
														for(int col=5;col<=7;col+=2) {
															if (panneau[Ln][col]==" ") {
																
																if(panneau[Ln-2][col-2]=="R"&&panneau[Ln-4][col-4]=="R"&&panneau[Ln+2][col]!=" ") {
																	panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
																}
															}
														}
													}
												}
										
										/*
										 * 
										 * mettre le pion avoir 3 J linge
										 */
										
										
										//horizontale
										
										if(nombre!=999) {
											labe:for(int Ln=11;Ln>=1;Ln-=2) {
												for(int col=1;col<=9;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln][col+2]=="J"&&panneau[Ln][col+4]=="J"&&Ln==11) {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
														if(panneau[Ln][col+2]=="J"&&panneau[Ln][col+4]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
														}
													}
												}
											}
											}
										
										
											if(nombre!=999) {
											labe: for(int Ln=11;Ln>=1;Ln-=2) {
												for(int col=3;col<=11;col+=2) {
													if (panneau[Ln][col]==" ") {
														if(panneau[Ln][col-2]=="J"&&panneau[Ln][col+2]=="J"&&Ln==11) {
															panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
														}
														if(panneau[Ln][col-2]=="J"&&panneau[Ln][col+2]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
															panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
														}
													}
												}
											 }
											}
											if(nombre!=999) {
												labe: for(int Ln=11;Ln>=1;Ln-=2) {
													for(int col=5;col<=13;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln][col-2]=="J"&&panneau[Ln][col-4]=="J"&&Ln==11) {
																panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
															}
															if(panneau[Ln][col-2]=="J"&&panneau[Ln][col-4]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
															}
														}
													}
												 }
												}
											//verticale
											if(nombre!=999) {
											labe:for(int Ln=7;Ln>=1;Ln-=2) {
													for(int col=1;col<=13;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+2][col]=="J"&&panneau[Ln+4][col]=="J") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
												 	}
												 }
											}
											
											
											//BG-HD(VRR)11-1,1-11
											if(nombre!=999) {
											labe:for(int Ln=11;Ln>=5;Ln-=2) {
													for(int col=1;col<=7;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&Ln==11) {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
											//BG-HD(RVR)11-1,1-11
											if(nombre!=999) {
											labe:for(int Ln=9;Ln>=3;Ln-=2) {
													for(int col=3;col<=9;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
											}
											
											//BG-HD(RRV)11-1,1-11
											if(nombre!=999) {
											labe:for(int Ln=7;Ln>=1;Ln-=2) {
													for(int col=5;col<=11;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
											}
											
											//BG-HD(VRR)11-3,1-13
											if(nombre!=999) {
											labe:for(int Ln=11;Ln>=5;Ln-=2) {
													for(int col=3;col<=9;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&Ln==11) {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
											//BG-HD(RVR)11-3,1-13
											if(nombre!=999) {
											labe:for(int Ln=9;Ln>=3;Ln-=2) {
													for(int col=5;col<=11;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
											}
											
											//BG-HD(RRV)11-3,1-13
											if(nombre!=999) {
											labe:for(int Ln=5;Ln>=1;Ln-=2) {
													for(int col=7;col<=13;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
											}
											//BG-HD(VRR)9-1,1-9
											if(nombre!=999) {
											labe:for(int Ln=9;Ln>=5;Ln-=2) {
													for(int col=1;col<=5;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
											//BG-HD(RVR)9-1,1-9
											if(nombre!=999) {
											labe:for(int Ln=7;Ln>=3;Ln-=2) {
													for(int col=3;col<=7;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
											}
											
											//BG-HD(RRV)9-1,1-9
											if(nombre!=999) {
											labe:for(int Ln=5;Ln>=1;Ln-=2) {
													for(int col=5;col<=9;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
											}
											//BG-HD(VRR)11-5,3-13
											if(nombre!=999) {
											labe:for(int Ln=11;Ln>=7;Ln-=2) {
													for(int col=5;col<=9;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&Ln==11) {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
											//BG-HD(RVR)11-5,3-13
											if(nombre!=999) {
											labe:for(int Ln=9;Ln>=5;Ln-=2) {
													for(int col=7;col<=11;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
											}
											
											//BG-HD(RRV)11-5,3-13
											if(nombre!=999) {
											labe:for(int Ln=7;Ln>=3;Ln-=2) {
													for(int col=9;col<=13;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
											}
										
											//BG-HD(VRR)11-7,5-13
											if(nombre!=999) {
												labe:for(int Ln=11;Ln>=9;Ln-=2) {
													for(int col=7;col<=9;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln-4][col+4]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
													
												
											}
											//BG-HD(RVR)11-7,5-13
											if(nombre!=999) {
												labe:for(int Ln=9;Ln>=7;Ln-=2) {
													for(int col=9;col<=11;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
													
												
											}
											
											//BG-HD(RRV)11-7,5-13
											if(nombre!=999) {
												labe:for(int Ln=7;Ln>=5;Ln-=2) {
													for(int col=11;col<=13;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col-2]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
													
												
											}
											//BG-HD(VRR)7-1,1-7
											if(nombre!=999) {
												labe:for(int Ln=7;Ln>=5;Ln-=2) {
													for(int col=1;col<=3;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln-2][col+2]=="J"&&panneau[Ln-4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
													
												
											}
											//BG-HD(RVR)7-1,1-7
											if(nombre!=999) {
												labe:for(int Ln=5;Ln>=3;Ln-=2) {
													for(int col=3;col<=5;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+2][col-2]=="J"&&panneau[Ln-2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
													
												
											}
											
											//BG-HD(RRV)7-1,1-7
											if(nombre!=999) {
												labe:for(int Ln=3;Ln>=1;Ln-=2) {
													for(int col=5;col<=7;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln+2][col-2]=="J"&&panneau[Ln+4][col-4]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															
														}
													}
												}
													
												
											}
											
											/**
											 * HG-BD
											 */
											
											// HG-BD(VRR)1-1,11-11
											if(nombre!=999) {
											labe:for(int Ln=1;Ln<=7;Ln+=2) {
													for(int col=1;col<=7;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
											// HG-BD(RVR)1-1,11-11
											if(nombre!=999) {
											labe:for(int Ln=3;Ln<=9;Ln+=2) {
													for(int col=3;col<=9;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
															
											// HG-BD(RRV)1-1,11-11
											if(nombre!=999) {
												labe:for(int Ln=5;Ln<=11;Ln+=2) {
														for(int col=5;col<=11;col+=2) {
															if (panneau[Ln][col]==" ") {
																
																if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&Ln==11) {
																	panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
																}
																if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
																	panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
																}
															}
														}
													}
												}
											// HG-BD(VRR)3-1,11-9
											if(nombre!=999) {
											labe:for(int Ln=3;Ln<=7;Ln+=2) {
													for(int col=1;col<=5;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
											// HG-BD(RVR)3-1,11-9
											if(nombre!=999) {
											labe:for(int Ln=5;Ln<=9;Ln+=2) {
													for(int col=3;col<=7;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
																
											// HG-BD(RRV)3-1,11-9
											if(nombre!=999) {
											labe:for(int Ln=11;Ln>=7;Ln-=2) {
													for(int col=5;col<=9;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&Ln==11) {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															if(panneau[Ln-4][col-4]=="J"&&panneau[Ln-2][col-2]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
											// HG-BD(VRR)1-3,11-13
											if(nombre!=999) {
											labe:for(int Ln=1;Ln<=7;Ln+=2) {
													for(int col=3;col<=9;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
											// HG-BD(RVR)1-3,11-13
											if(nombre!=999) {
											labe:for(int Ln=3;Ln<=9;Ln+=2) {
													for(int col=5;col<=11;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
															
											// HG-BD(RRV)1-3,11-13
											if(nombre!=999) {
											labe:for(int Ln=5;Ln<=11;Ln+=2) {
													for(int col=7;col<=13;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&Ln==11) {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
											// HG-BD(VRR)1-5,9-13
											if(nombre!=999) {
											labe:for(int Ln=1;Ln<=5;Ln+=2) {
													for(int col=5;col<=9;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
											// HG-BD(RVR)1-5,9-13
											if(nombre!=999) {
											labe:for(int Ln=3;Ln<=7;Ln+=2) {
													for(int col=7;col<=11;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
														
											// HG-BD(RRV)1-5,9-13
											if(nombre!=999) {
											labe:for(int Ln=5;Ln<=9;Ln+=2) {
													for(int col=9;col<=13;col+=2) {
														if (panneau[Ln][col]==" ") {
															
															if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
											}
											// HG-BD(VRR)1-7,7-13
											if(nombre!=999) {
												labe:for(int Ln=1;Ln<=3;Ln+=2) {
														for(int col=7;col<=9;col+=2) {
															if (panneau[Ln][col]==" ") {
																
																if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
																	panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
																}
															}
														}
													}
												}
											// HG-BD(RVR)1-7,7-13
											if(nombre!=999) {
												labe:for(int Ln=3;Ln<=5;Ln+=2) {
														for(int col=9;col<=11;col+=2) {
															if (panneau[Ln][col]==" ") {
																
																if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
																	panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
																}
															}
														}
													}
												}
													
											
											// HG-BD(RRV)1-7,7-13
											if(nombre!=999) {
												labe:for(int Ln=5;Ln<=7;Ln+=2) {
														for(int col=11;col<=13;col+=2) {
															if (panneau[Ln][col]==" ") {
																
																if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln+2][col]!=" ") {
																	panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
																}
															}
														}
													}
												}
											// HG-BD(VRR)5-1,11-7
											if(nombre!=999) {
												labe:for(int Ln=5;Ln<=7;Ln+=2) {
														for(int col=1;col<=5;col+=2) {
															if (panneau[Ln][col]==" ") {
																
																if(panneau[Ln+2][col+2]=="J"&&panneau[Ln+4][col+4]=="J"&&panneau[Ln+2][col]!=" ") {
																	panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
																}
															}
														}
													}
												}
											// HG-BD(RVR)5-1,11-7
											if(nombre!=999) {
												labe:for(int Ln=7;Ln<=9;Ln+=2) {
														for(int col=3;col<=5;col+=2) {
															if (panneau[Ln][col]==" ") {
																
																if(panneau[Ln-2][col-2]=="J"&&panneau[Ln+2][col+2]=="J"&&panneau[Ln+2][col]!=" ") {
																	panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
																}
															}
														}
													}
												}
													
													
											// HG-BD(RRV)5-1,11-7
											if(nombre!=999) {
												labe:for(int Ln=9;Ln<=11;Ln+=2) {
														for(int col=5;col<=7;col+=2) {
															if (panneau[Ln][col]==" ") {
																
																if(panneau[Ln-2][col-2]=="J"&&panneau[Ln-4][col-4]=="J"&&panneau[Ln+2][col]!=" ") {
																	panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
																}
															}
														}
													}
												}
											/**
											 * 
											 * trouver 2R
											 */
                                           //horizontale
											
											if(nombre!=999) {
												labe:for(int Ln=11;Ln>=1;Ln-=2) {
													for(int col=1;col<=11;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln][col+2]=="R"&&Ln==11) {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															if(panneau[Ln][col+2]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
												}
											
											
												
												if(nombre!=999) {
													labe: for(int Ln=11;Ln>=1;Ln-=2) {
														for(int col=3;col<=13;col+=2) {
															if (panneau[Ln][col]==" ") {
																if(panneau[Ln][col-2]=="R"&&Ln==11) {
																	panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
																}
																if(panneau[Ln][col-2]=="R"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
																	panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
																}
															}
														}
													 }
													}
												
												//verticale
												if(nombre!=999) {
												labe:for(int Ln=9;Ln>=1;Ln-=2) {
														for(int col=1;col<=13;col+=2) {
															if (panneau[Ln][col]==" ") {
																if(panneau[Ln+2][col]=="R") {
																	panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
																}
															}
													 	}
													 }
												}
												
												
											
											
											/*
											 * 
											 * mettre le pion avoir 2 J linge
											 */
											
											
											//horizontale
											
											if(nombre!=999) {
												labe:for(int Ln=11;Ln>=1;Ln-=2) {
													for(int col=1;col<=11;col+=2) {
														if (panneau[Ln][col]==" ") {
															if(panneau[Ln][col+2]=="J"&&Ln==11) {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
															if(panneau[Ln][col+2]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
																panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
															}
														}
													}
												}
												}
											
											
												
												if(nombre!=999) {
													labe: for(int Ln=11;Ln>=1;Ln-=2) {
														for(int col=3;col<=13;col+=2) {
															if (panneau[Ln][col]==" ") {
																if(panneau[Ln][col-2]=="J"&&Ln==11) {
																	panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
																}
																if(panneau[Ln][col-2]=="J"&&Ln!=11&&panneau[Ln+2][col]!=" ") {
																	panneau[Ln][col]="J";nombre=999;L=Ln;C=col;break labe;
																}
															}
														}
													 }
													}
												
												//verticale
												if(nombre!=999) {
												labe:for(int Ln=9;Ln>=1;Ln-=2) {
														for(int col=1;col<=13;col+=2) {
															if (panneau[Ln][col]==" ") {
																if(panneau[Ln+2][col]=="J") {
																	panneau[Ln][col]="J";nombre=999;C=col;L=Ln;break labe;
																}
															}
													 	}
													 }
												}
												
												
											
										

								if(nombre<4) {							
								 L=11;
							     C=(int)(Math.random()*13+1);
							      if(C%2 !=1) {
							    	  C++;
							      }
							     verifier_a: 
							    for(L=11;L>=1;L-=2) {  
								  if(panneau[L][C] == " ") {
									  panneau[L][C]="J";break verifier_a ;
								  }
							    }
							     if(panneau[1][C]!=" ") {
							    	 verifier_c :
											for(C=1;C<=13;C+=2) {
												
												 for(L=11;L>=1;L-=2) {
													 
													  if(panneau[L][C] == " ") {
														  panneau[L][C]="J";break verifier_c;
													  }
														  
													  
												  }
													
												
											}
							     }
							     
								}
							     
								  
								
								
								
								int nombrePc=-1;
								int maxPc =0;
								int a=L;
								int b=C;
								String jetonPc= ("J");
								a=L; b=C;nombrePc=-1;
								while(a >= 0 && b >= 0 && panneau[a][b] == jetonPc){ a-=2; b-=2; nombrePc++;}
								a=L; b=C;
								while(a<=11 && b<=13 && panneau[a][b] == jetonPc){ a+=2; b+=2; nombrePc++;}
								if(nombre > maxPc) maxPc= nombrePc;
								
								
								//-->  diagonale HD-BG
								a=L; b=C;nombrePc=-1;
								while(a >= 0 && b <= 13 && panneau[a][b] == jetonPc){ a-=2; b+=2; nombrePc++;}
								a=L; b=C;
								while(a <= 11 && b >=0 && panneau[a][b] == jetonPc){ a+=2; b-=2; nombrePc++;}
								if(nombrePc > maxPc) maxPc= nombrePc;
								
							
								//-->  verticale:
								a=L; b=C;nombrePc=-1;
								while(a >= 0 && panneau[a][b] == jetonPc){ a-=2; nombrePc++;}
								a=L;  
								while(a <= 11 && panneau[a][b] == jetonPc){ a+=2; nombrePc++;}
								if(nombrePc > maxPc) maxPc= nombrePc;
							
								
								//-->  horizontale:
								a=L; b=C;nombrePc=-1;
								while(b >= 0 && panneau[a][b] == jetonPc){ b-=2; nombrePc++;}
								b=C;
								while(b <= 13 && panneau[a][b] == jetonPc){ b+=2; nombrePc++;}
								if(nombrePc > maxPc) maxPc= nombrePc;
								
								
								if(maxPc >= 4){
									gagnant = 2;
									i = 999; break;
								}
								System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
								
						}
								//affichage des résultats:
								// si gagnant == 0 c'est que tout le échiquier s'est remplis sans gagnant, il y a donc égalité
								
								System.out.println();
								System.out.println("#########################");
								System.out.println("    Fin de la partie     ");
								System.out.println("#########################");
								if(gagnant == 0)
									System.out.println("*******EGALITE*******");
								if(gagnant == 1) {
									System.out.println("****"+"Le gagnant est "+nom+"****");
								    System.out.println(     "Felicitations a "+nom+" !"  );
								}
								if(gagnant == 2) {
									System.out.println("****"+"Le gagnant est computer****");
									System.out.println(     "Felicitations a computer!"  );
								}
							    System.out.println(" ");
								System.out.println("____________  Affichage final du panneau______________");
							
								
								for (int x = 0; x < panneau.length; x++){
						            for (int y = 0; y<panneau[x].length; y++){
						                System.out.print(panneau[x][y]);
						            }
						        
							}
								System.out.println(" ");
								System.out.println("_________________________FIN____________________________");
							
				    	
				    
				     
				    
				    
				}
				    
				}
			
				
}


			





